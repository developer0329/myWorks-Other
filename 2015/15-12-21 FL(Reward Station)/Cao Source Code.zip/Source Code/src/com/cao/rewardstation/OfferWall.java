package com.cao.rewardstation;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class OfferWall extends Activity {

	   private WebView wv1;
	    private ProgressDialog progressBar;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_offer_wall);
		Intent intent = getIntent();
		String url = intent.getStringExtra("url");

	      wv1=(WebView)findViewById(R.id.webview);

	    //  wv1.setWebViewClient(new MyBrowser()); 
	      wv1.getSettings().setLoadsImagesAutomatically(true);
       wv1.getSettings().setJavaScriptEnabled(true);
       wv1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    //   wv1.loadUrl(url);
       
       final AlertDialog alertDialog = new AlertDialog.Builder(this).create();

       progressBar = ProgressDialog.show(OfferWall.this, "Loading", "Loading Sponsored Offers...");

       
       wv1.setWebViewClient(new WebViewClient() {
           public boolean shouldOverrideUrlLoading(WebView view, String url) {
           //    Log.i(TAG, "Processing webview url click...");
         	  Log.e("Ovveride",url);
 	    	  if ((url.contains("market://")
                       || url.contains("play.google.com")
                       || url.contains("plus.google.com")
                       || url.contains("facebook.com")
                       || url.contains("twitter.com")
                       || url.contains("linkedin.com")
                       || url.contains("https://youtu.be")
                       || url.contains("youtube.com")
                       || url.contains("whatsapp://")
                       || url.contains("mailto:") || url.contains("tel:")
                       || url.contains("vid:") || url.contains("geo:")
                       || url.contains("sms:") || url.contains("intent://")) == true)
 	    	  {
                   // Load new URL Don't override URL Link
                   try {
                       view.getContext().startActivity(
                               new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                   } catch(ActivityNotFoundException e) {
          	         view.loadUrl(url);
                   }

                   return true;
               } else {
 	         view.loadUrl(url);
               }
 	         return true;
 	      }

           public void onPageFinished(WebView view, String url) {
           //    Log.i(TAG, "Finished loading URL: " + url);
               if (progressBar.isShowing()) {
                   progressBar.dismiss();
               }
           }

           public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
         //      Log.e(TAG, "Error: " + description);
               Toast.makeText(OfferWall.this, "Oh no! " + description, Toast.LENGTH_SHORT).show();
               alertDialog.setTitle("Error");
               alertDialog.setMessage(description);
               alertDialog.show();
           }
       });
       wv1.loadUrl(url);
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
