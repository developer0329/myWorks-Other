package com.cao.rewardstation;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.squareup.picasso.Picasso;


public class OfferAdapter extends RecyclerView.Adapter<OfferAdapter.ViewHolder>  {
	 
    private static final int TYPE_HEADER = 0;  // Declaring Variable to Understand which View is being worked on
                                               // IF the viaew under inflation and population is header or Item
    private static final int TYPE_ITEM = 1;
    private int current;
    User UserProfile;
    private String dataSource[]; // String Array to store the passed titles Value from MainActivity.java
    private int mIcons[];       // Int Array to store the passed icons resource value from MainActivity.java
 
    private int profile;        //int Resource for header view profile picture
    Context context; 
    AdscendActivity Activity;
    // Creating a ViewHolder which extends the RecyclerView View Holder
    // ViewHolder are used to to store the inflated views in order to recycle them
 
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {    
    	int Holderid;
    	protected TextView Name;
        protected TextView Description;
        protected TextView Credits;
        protected TextView Category;
        protected TextView Cost;
        protected ImageView pic;
        protected String appid;
        protected RatingBar RatingBar;
        protected Button AssignButton;
        protected Button DeleteButton;
        protected  Spinner dynamicSpinner;
        protected String URL;
        Context contxt;
        AdscendActivity mActivity;
 
        public ViewHolder(View itemView,int ViewType,Context c,AdscendActivity Activ) {                 // Creating ViewHolder Constructor with View and viewType As a parameter
            super(itemView);
             contxt = c;
             mActivity = Activ;
            itemView.setClickable(true);
            itemView.setOnClickListener(this);
            // Here we set the appropriate view in accordance with the the view type as passed when the holder object is created
 
            if(ViewType == TYPE_ITEM) {

                Name =  (TextView) itemView.findViewById(R.id.Name);
                Category =  (TextView) itemView.findViewById(R.id.category);
                Cost =  (TextView) itemView.findViewById(R.id.cost);
                pic = (ImageView) itemView.findViewById(R.id.Icon);
                Description =  (TextView) itemView.findViewById(R.id.Description);
                Credits =  (TextView) itemView.findViewById(R.id.Credits);// setting holder id as 1 as the object being populated are of type item row
                Holderid = 1;    
            }
            else{                                              // Setting holder id = 0 as the object being populated are of type header view

    	        Holderid = 0;    
            }
 
 
 
        }
 
 

        @Override
              public void onClick(View v) {
              	OfferDialog();
              }
              
              
      		public void OfferDialog(){
                    	new AlertDialog.Builder(mActivity)
                        .setTitle(Name.getText())
                        .setMessage(Description.getText())
                        .setPositiveButton("START", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) { 
                                // continue with delete

                            	if(URL.equalsIgnoreCase("x")){
                            		Intent share = new Intent(android.content.Intent.ACTION_SEND);
             					 share.setType("text/plain");
             						share.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id="+mActivity.getApplicationContext().getPackageName());

             						mActivity.startActivity(Intent.createChooser(share, "Share your Invitation link"));
             					
                            	} else {
                            	Intent i = new Intent(Intent.ACTION_VIEW);
                            	i.setData(Uri.parse(URL));
                            	i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            	contxt.startActivity(i);
                          	
                            	}
                            }
                        		})
                   
                        .setIcon(pic.getDrawable())//android.R.drawable.ic_dialog_alert)
                         .show();
                    }
      		
    }
 
 
 
    OfferAdapter(String Titles[],Context passedContext,AdscendActivity Activ){ // DrawerAdapter Constructor with titles and icons parameter
                                            // titles, icons, name, email, profile pic are passed from the main activity as we
    	dataSource = Titles;       
        Activity = Activ;                //here we assign those passed values to the values we declared here
        this.context = passedContext;
 
        //in adapter
 
 
 
    }
 
 
    @Override
    public OfferAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
 
        if (viewType == TYPE_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.offer_row,parent,false); //Inflating the layout
 
            ViewHolder vhItem = new ViewHolder(v,viewType,context,Activity); //Creating ViewHolder and passing the object of type view
 
            return vhItem; // Returning the created object
 
            //inflate your layout and pass it to view holder
 
        } else if (viewType == TYPE_HEADER) {
 
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.offer_header,parent,false); //Inflating the layout
 
            ViewHolder vhHeader = new ViewHolder(v,viewType,context,Activity); //Creating ViewHolder and passing the object of type view
 
            return vhHeader; //returning the object created
 
 
        }
        return null;
 
    }
 
    //Next we override a method which is called when the item in a row is needed to be displayed, here the int position
    // Tells us item at which position is being constructed to be displayed and the holder id of the holder object tell us
    // which view type is being created 1 for item row


    @Override
    public void onBindViewHolder(OfferAdapter.ViewHolder holder, int position) {
        if(holder.Holderid ==1) {
        	final int mPos = position;
        	final OfferAdapter.ViewHolder myHolder = holder;
        	JSONObject Offer;
        	String id= null,name= null,description= null,creative = null,url= null,category= null,cost= null,credits = null;
        	Double  payout;int finalpayout = 0;
        	try {
            	String OfferFull = dataSource[position];
            	if (position==1){
            		
            		Log.e("Position =1 ","true");
            		holder.Name.setText("Invite your Friends !");
		            holder.Description.setText("Get 20% Credits on completed offers from each of your referred friends");
		            holder.Credits.setText("20%");
		            holder.URL="x";
		            holder.pic.setImageResource(R.drawable.ic_facebook);
			        holder.Category.setText("Share");
		           
            		
            	} 
            	else { //Begin else

            		Log.e("Position = Else ",String.valueOf(position));
        		Offer = new JSONObject(OfferFull);
        		id = Offer.getString("id");
        		name = Offer.getString("name");
        		description = Offer.getString("description");
        		JSONArray creativex = Offer.getJSONArray("creative");
        		creative = creativex.getString(0);
        		url = Offer.getString("url");
        		category = Offer.getString("conv_point");
        		cost = Offer.getString("cost");
        		payout = Double.parseDouble(Offer.getString("payout"));
        		Double creditpayout = payout/0.05;
        		 finalpayout = creditpayout.intValue();
        		credits = String.valueOf(finalpayout);
        		
        	
        	
		            Picasso.with(context)
		            .load(creative)
		            .placeholder(R.drawable.ic_launcher)
		            .transform(new RoundedTransformation(10, 4))
		            .into(holder.pic);
		            
		            holder.Name.setText(name);
		            holder.Description.setText(description);
		            holder.Credits.setText(credits);
		            holder.URL=url;
		            
		
		           String[] categoryarray = context.getResources().getStringArray(R.array.categories);
		           int finalcateg = Integer.parseInt(category);
		           holder.Category.setText(categoryarray[finalcateg]);
		            
				        if(cost.equalsIgnoreCase("0.00")){
				            holder.Cost.setText("FREE");
				        	}else {
				            holder.Cost.setText(cost);
				            }
        			}	// End else
			        
			        } catch (Throwable t) {
			    	    Log.e("My App", "Could not parse malformed JSON");
			    	}
			        
        }
        else{
        }
    }		
   
    // This method returns the number of items present in the list
    @Override
    public int getItemCount() {
        return dataSource.length+1; // the number of items in the list will be +1 the titles including the header view.
    }
 
 
    // Witht the following method we check what type of view is being passed
    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
 
        return TYPE_ITEM;
    }
 
    private boolean isPositionHeader(int position) {
        return position == 0;
    }
 
}