package com.cao.rewardstation;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class Utils {

	 private void savePreferences(String key, String value, Context context) {
 	    SharedPreferences sharedPreferences = PreferenceManager
             .getDefaultSharedPreferences(context);
   Editor editor = sharedPreferences.edit();
 	    editor.putString(key, value);
 	     editor.commit();
 	
 	    }
}
