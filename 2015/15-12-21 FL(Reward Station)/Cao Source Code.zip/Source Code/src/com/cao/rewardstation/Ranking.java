package com.cao.rewardstation;

import java.util.ArrayList;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class Ranking  extends Fragment implements OnRefreshListener {
	RestClient MyRestClient;
	 Context mycontxt;
	 MainActivity activity;
	 RankAdapter adapter;  
	 private RecyclerView recyclerView;
	 private RecyclerView.LayoutManager layoutManager; 
	@Override
	 public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
	        View v =inflater.inflate(R.layout.ranking,container,false);
	        final ViewGroup containerx = container;
	        mycontxt=getActivity().getApplicationContext();
	        MyRestClient = ((MainActivity)this.getActivity()).getClient();
	        recyclerView = (RecyclerView) v.findViewById(R.id.recycler_view);
	        recyclerView.setHasFixedSize(true);
	        layoutManager = new LinearLayoutManager(this.getActivity());
	        recyclerView.setLayoutManager(layoutManager);
	        Typeface  PageFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Bold.otf"); 
			   TextView   PageTitle = (TextView) v.findViewById(R.id.PageTextView);

			   PageTitle.setTypeface(PageFont);
	        GetRank();
	        return v;    
	}

	public void GetRank() {
		 MyRestClient.APICONTROL.GetRank(new Callback<JsonElement>() {
		        @Override
		        public void success(JsonElement s, Response response) {
		        	JsonArray jsonObj = s.getAsJsonArray();
		        	ArrayList<String> RankList = null;
		        	RankList = new ArrayList<String>();
		        	int len = jsonObj.size();
	        		 RankList.add("Header");
	        		for(int i = 0; i < len; ++i) {
	        		JsonObject objd = jsonObj.get(i).getAsJsonObject();

	        		 String username = MyRestClient.YParser(objd.toString(),"name").replace("^", "");
	        		 String country = MyRestClient.YParser(objd.toString(),"country");
	        		 String credits = MyRestClient.YParser(objd.toString(),"credits");
	        		 String refs = MyRestClient.YParser(objd.toString(),"refs");
	        		 
	        		 RankList.add(objd.toString());
	        		 Log.e("Rank Final",username+"^"+country+"^"+credits+"^"+refs);
	        		}
	        		
	        		if (RankList.isEmpty()){
	        		Log.e("Rank List Empty","No users are ranked at the moment");
	        		}
	        		else {
	        			String[] RankListx = new String[RankList.size()];
	        			RankListx = RankList.toArray(RankListx);
		                adapter = new RankAdapter(RankListx,mycontxt,
		              		  ((MainActivity)getActivity()));
		                recyclerView.setAdapter(adapter);
		            }
	        	
		        }
		        @Override
		        public void failure(RetrofitError retrofitError) {
		            retrofitError.printStackTrace(); //to see if you have errors
			        String StatusCode = null;String Message = null; 
		            try {
			            	String GetResponse = new String(((TypedByteArray) retrofitError.getResponse().getBody()).getBytes());
			            	 StatusCode = MyRestClient.StatusParser(GetResponse);
			            	 Message= MyRestClient.MessageParser(GetResponse);

		            		 Log.e("Rank Status","Fail");
			            	 
			            }
			            catch (Exception e) {// NOT JSON, CANT PARSE IT.

			            	Log.e("Response Error","Bad Json");
			            }	
		            	
		            	if ( (StatusCode!=null) && (Message!=null)) {
//		            	ShowError(StatusCode,Message);
//		            	 ShowForm(true);
	           		}else { // NOT JSON, CANT PARSE IT.
//	            			ShowError("XXX",getString(R.string.BadJsonResponse));
//	            			 ShowForm(true);
	            		}
						
					}
		 		});  
		    }

	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		  GetRank();
	        
	}
}