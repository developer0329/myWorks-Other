package com.cao.rewardstation;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.github.johnpersano.supertoasts.SuperCardToast;
import com.github.johnpersano.supertoasts.SuperToast;
import com.github.johnpersano.supertoasts.util.OnClickWrapper;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.jirbo.adcolony.AdColony;
import com.jirbo.adcolony.AdColonyV4VCAd;
import com.nativex.monetization.MonetizationManager;
import com.nativex.monetization.enums.NativeXAdPlacement;
import com.nativex.monetization.listeners.SessionListener;
import com.parse.ParseInstallation;

public class MainActivity extends AppCompatActivity implements  SessionListener {

    Toolbar toolbar;
    MyPageAdapter pageAdapter;

	private InterstitialAd interstitial;
    int Numboftabs =5;
	 RestClient MyRestClient;
    User UserProfile;TextView usercredits ;   ViewPager pager;
    


    private SessionListener sessionListener = new SessionListener() {
        @Override
        public void createSessionCompleted(boolean success, boolean isOfferWallEnabled, String sessionId) {
            if (success) {
                // a session with our servers was established successfully.
                // the app is now ready to show ads.
                System.out.println("Wahoo! Now I'm ready to show an ad.");
            } else {
                // establishing a session with our servers failed;
                // the app will be unable to show ads until a session is established 
                System.out.println("Oh no! Something isn't set up correctly - re-read the documentation or ask customer support for some help - https://selfservice.nativex.com/Help");
            }
        }
    };
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		 SuperCardToast.onRestoreState(savedInstanceState, this);
	       
		Intent intent = getIntent();
	UserProfile = (User) intent.getSerializableExtra("UserProfile");
//
       MyRestClient = new RestClient();

    	SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
     	String Email = preferences.getString("Email", "");
     	String Password = preferences.getString("Password", "");

     	
    	ParseInstallation.getCurrentInstallation().put("country", UserProfile.getcountry());
  		ParseInstallation.getCurrentInstallation().put("userid", UserProfile.getid());
       ParseInstallation.getCurrentInstallation().saveInBackground();
        Login(Email,Password);
	    CharSequence Titles[]= getResources().getStringArray(R.array.tabs);
	    pageAdapter = new MyPageAdapter(getSupportFragmentManager(),Titles,Numboftabs);
//
	     pager = (ViewPager)findViewById(R.id.viewpager);
	    usercredits = (TextView)findViewById(R.id.Credits);
	    usercredits.setText(String.valueOf(UserProfile.getcredits()));
	    pager.setAdapter(pageAdapter);
	    
	    LoadInterstitial();
	    
	    //Adcolony
	    AdColony.setCustomID(String.valueOf(UserProfile.getid()));
	    Log.e("Custom Id",String.valueOf(UserProfile.getid()));
	    //Ad Colony
	    AdColony.configure(this, "version:1.1,store:google", getString(R.string.AdcolonyAppId), getString(R.string.AdcolonyZoneId));
        

 		
	    // Assiging the Sliding Tab Layout View
	    SlidingTabLayout  tabs = (SlidingTabLayout) findViewById(R.id.tabs);
        tabs.setDistributeEvenly(true); // To make the Tabs Fixed set this true, This makes the tabs Space Evenly in Available width
 

        
        
        tabs.setCustomTabView(R.layout.tab_layout, R.id.tabtext);
        // Setting Custom Color for the Scroll bar indicator of the Tab View
        tabs.setCustomTabColorizer(new SlidingTabLayout.TabColorizer() {
            @Override
            public int getIndicatorColor(int position) {
                return getResources().getColor(R.color.tabselector);
            }
        });
 
        // Setting the ViewPager For the SlidingTabsLayout
        tabs.setViewPager(pager);
 
 
        if (UserProfile.getnotifs()>0) {
        	LaunchNotif(UserProfile.getnotifs());
        }
	    
	    
	}


public void LoadInterstitial() {

		interstitial = new InterstitialAd(MainActivity.this);
	
		interstitial.setAdUnitId(getString(R.string.Admob));
	
		
		AdRequest adRequest = new AdRequest.Builder()
			.build();
		interstitial.loadAd(adRequest);
		 
	
}


	  public void Login(final String email,final String password) {

	 MyRestClient.APICONTROL.login(email,password,new Callback<JsonElement>() {
	        @Override
	        public void success(JsonElement s, Response response) {
	        	JsonObject jsonObj = s.getAsJsonObject();
	        	String strObj = jsonObj.toString();
	        	//process your response if login successfull you can call Intent and launch your main activity

       		 Log.e("Login Status","success");
	        }
	        @Override
	        public void failure(RetrofitError retrofitError) {
	            retrofitError.printStackTrace(); //to see if you have errors
		        String StatusCode = null;String Message = null; 
	            try {
		            	String GetResponse = new String(((TypedByteArray) retrofitError.getResponse().getBody()).getBytes());
		            	 StatusCode = MyRestClient.StatusParser(GetResponse);
		            	 Message= MyRestClient.MessageParser(GetResponse);

	            		 Log.e("Login Status","Fail");
		            	 
		            }
		            catch (Exception e) {// NOT JSON, CANT PARSE IT.

		            	Log.e("Response Error","Bad Json");
		            }	
	            	
	            	if ( (StatusCode!=null) && (Message!=null)) {
//	            	ShowError(StatusCode,Message);
//	            	 ShowForm(true);
           		}else { // NOT JSON, CANT PARSE IT.
//            			ShowError("XXX",getString(R.string.BadJsonResponse));
//            			 ShowForm(true);
            		}
					
				}
	    });  
	          
 }
    

	

    public RestClient getClient(){
    	   return this.MyRestClient;
    	 }
    
    public User getUserProfile(){
 	   return this.UserProfile;
 	 }
    
    public void LaunchNotif(int numberofnotifs){
    	SuperCardToast superCardToast = new SuperCardToast(MainActivity.this, SuperToast.Type.BUTTON);
    	superCardToast.setBackground(SuperToast.Background.ORANGE);
    	superCardToast.setIndeterminate(true);
    	superCardToast.setTextColor(Color.WHITE);
    	superCardToast.setText(getString(R.string.NewNotifications1)+" "+String.valueOf(numberofnotifs)+" "+getString(R.string.NewNotifications2));
    	superCardToast.setButtonIcon(SuperToast.Icon.Dark.UNDO, getString(R.string.shownotifs));
    	OnClickWrapper onClickWrapper = new OnClickWrapper("supercardtoast", new SuperToast.OnClickListener() {
    		@Override
    	    public void onClick(View view, Parcelable token) {
    			pager.setCurrentItem(3);
    	    }
    	});

    	superCardToast.setOnClickWrapper(onClickWrapper);
    	superCardToast.show();
    }
    
    public void displayInterstitial() {
		// If Ads are loaded, show Interstitial else show nothing.
		if (interstitial.isLoaded()) {
			interstitial.show();
		}
	}
    
	
	
	public void ShowAdColony(){

		AdColonyV4VCAd ad = new AdColonyV4VCAd(getString(R.string.AdcolonyZoneId));
		ad.show();
	}
	
	
	
	public void shownativex(){
    	MonetizationManager.showAd(this, NativeXAdPlacement.Store_Open);
	}

	
	
	@Override
	public void onBackPressed() {
		displayInterstitial();
		finish();
	    return;
	}   
	
	@Override
	protected void onResume() {
	    super.onResume();
	    // The session listener is the one we defined in the previous step.
	    // createSession takes an application context, an AppId string, and a session listener.
		  AdColony.resume( this ); 
		  MonetizationManager.createSession(getApplicationContext(), getString(R.string.NativeX_AppId), String.valueOf(UserProfile.getid()), sessionListener);
	    }
	




	@Override
	//Listener callback for createSession
		public void createSessionCompleted(boolean success, boolean isOfferWallEnabled, String message) {
			if (success) {	
	            // A session with our servers was established successfully.
	            // The app is ready to show ads.
				System.out.println("Wahoo! We are now ready to show an ad!");
	    	
	    		
	    		//We are fetching all the ads here as this is a one scene app. 
	    		//However, in a typical integration you will want to spread these calls out in your game. 
	    		//It is recommended that you add these calls in an area that would allow around 5 seconds before attempting to show
	    			MonetizationManager.fetchAd(this, NativeXAdPlacement.Store_Open, null);
	    	} else {
	            // Establishing a session with our servers failed.
	            // The app will be unable to show ads until a session is established.
	        	System.out.println("Oh no! Something isn't set up correctly - re-read the documentation or ask customer support for help https://selfservice.nativex.com/Help");
	    
	        }
			
		}
	
	public void onPause() 
	{
	  super.onPause();
	  AdColony.pause(); 
	}


}
