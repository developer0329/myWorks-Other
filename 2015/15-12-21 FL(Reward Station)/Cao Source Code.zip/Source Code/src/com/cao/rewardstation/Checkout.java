package com.cao.rewardstation;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.github.johnpersano.supertoasts.SuperCardToast;
import com.github.johnpersano.supertoasts.SuperToast;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class Checkout extends Fragment {
	RestClient MyRestClient;
	 Context mycontxt;
	 MainActivity activity;
	 SuperCardToast ProgressToast;
	 User UserProfile;
	@Override
	 public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
	        View v =inflater.inflate(R.layout.checkout,container,false);
	        SuperCardToast.onRestoreState(savedInstanceState, this.getActivity());
	        final ViewGroup containerx = container;
	        ProgressToast = new SuperCardToast(this.getActivity(), SuperToast.Type.PROGRESS);
	      
	        MyRestClient = ((MainActivity)this.getActivity()).getClient();

		    UserProfile =  ((MainActivity) this.getActivity()).getUserProfile();
		    
	        mycontxt=this.getActivity();
	        
	       Typeface ItemFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Regular.otf"); 
	    	
	 	   Typeface  PageFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Bold.otf"); 
		   TextView   PageTitle = (TextView) v.findViewById(R.id.PageTextView);

		   TextView   paypaltext1 = (TextView) v.findViewById(R.id.paypaltext1);
		   TextView   paypaltext2 = (TextView) v.findViewById(R.id.paypaltext2);
		   TextView   paypaltext3 = (TextView) v.findViewById(R.id.paypaltext3);
		   TextView   paypaltext4 = (TextView) v.findViewById(R.id.paypaltext4);
		   TextView   paypaltext5 = (TextView) v.findViewById(R.id.paypaltext5);
		   TextView   paypaltext6 = (TextView) v.findViewById(R.id.paypaltext6);
		   TextView   paypaltext7 = (TextView) v.findViewById(R.id.paypaltext7);
		   TextView   paypaltext8 = (TextView) v.findViewById(R.id.paypaltext8);
		   


		   TextView   amazontext1 = (TextView) v.findViewById(R.id.amazontext1);
		   TextView   amazontext2 = (TextView) v.findViewById(R.id.amazontext2);
		   TextView   amazontext3 = (TextView) v.findViewById(R.id.amazontext3);
		   TextView   amazontext4 = (TextView) v.findViewById(R.id.amazontext4);
		   

		   TextView   googletext1 = (TextView) v.findViewById(R.id.googletext1);
		   TextView   googletext2 = (TextView) v.findViewById(R.id.googletext2);
		   TextView   googletext3 = (TextView) v.findViewById(R.id.googletext3);
		   TextView   googletext4 = (TextView) v.findViewById(R.id.googletext4);
		   

		   TextView   xboxtext1 = (TextView) v.findViewById(R.id.xboxtext1);
		   TextView   xboxtext2 = (TextView) v.findViewById(R.id.xboxtext2);
		   TextView   xboxtext3 = (TextView) v.findViewById(R.id.xboxtext3);
		   TextView   xboxtext4 = (TextView) v.findViewById(R.id.xboxtext4);
		   
		   PageTitle.setTypeface(PageFont);
		   paypaltext1.setTypeface(ItemFont);
		   paypaltext2.setTypeface(ItemFont);
		   paypaltext3.setTypeface(ItemFont);
		   paypaltext4.setTypeface(ItemFont);
		   paypaltext5.setTypeface(ItemFont);
		   paypaltext6.setTypeface(ItemFont);
		   paypaltext7.setTypeface(ItemFont);
		   paypaltext8.setTypeface(ItemFont);


		   amazontext1.setTypeface(ItemFont);
		   amazontext2.setTypeface(ItemFont);
		   amazontext3.setTypeface(ItemFont);
		   amazontext4.setTypeface(ItemFont);

		   googletext1.setTypeface(ItemFont);
		   googletext2.setTypeface(ItemFont);
		   googletext3.setTypeface(ItemFont);
		   googletext4.setTypeface(ItemFont);

		   xboxtext1.setTypeface(ItemFont);
		   xboxtext2.setTypeface(ItemFont);
		   xboxtext3.setTypeface(ItemFont);
		   xboxtext4.setTypeface(ItemFont);
		   
	     RelativeLayout Paypal1 = (RelativeLayout) v.findViewById(R.id.paypal1);
	     Paypal1.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.paypalvalue1),getString(R.string.paypaltitle1),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	        
	     RelativeLayout Paypal2 = (RelativeLayout) v.findViewById(R.id.paypal2);
	     Paypal2.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.paypalvalue2),getString(R.string.paypaltitle2),String.valueOf(UserProfile.getid()));
	            	
	            }
	        }); 
	     
	     RelativeLayout Paypal3 = (RelativeLayout) v.findViewById(R.id.paypal3);
	     Paypal3.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.paypalvalue3),getString(R.string.paypaltitle3),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout Paypal4 = (RelativeLayout) v.findViewById(R.id.paypal4);
	     Paypal4.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.paypalvalue4),getString(R.string.paypaltitle4),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout Paypal5 = (RelativeLayout) v.findViewById(R.id.paypal5);
	     Paypal5.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.paypalvalue5),getString(R.string.paypaltitle5),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout Paypal6 = (RelativeLayout) v.findViewById(R.id.paypal6);
	     Paypal6.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.paypalvalue6),getString(R.string.paypaltitle6),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout Paypal7 = (RelativeLayout) v.findViewById(R.id.paypal7);
	     Paypal7.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.paypalvalue7),getString(R.string.paypaltitle7),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout Paypal8 = (RelativeLayout) v.findViewById(R.id.paypal8);
	     Paypal8.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.paypalvalue8),getString(R.string.paypaltitle8),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     

	   
	     RelativeLayout amazon1 = (RelativeLayout) v.findViewById(R.id.amazon1);
	     amazon1.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.amazonvalue1),getString(R.string.amazontitle1),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	        
	     RelativeLayout amazon2 = (RelativeLayout) v.findViewById(R.id.amazon2);
	     amazon2.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.amazonvalue2),getString(R.string.amazontitle2),String.valueOf(UserProfile.getid()));
	            	
	            }
	        }); 
	     
	     RelativeLayout amazon3 = (RelativeLayout) v.findViewById(R.id.amazon3);
	     amazon3.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.amazonvalue3),getString(R.string.amazontitle3),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout amazon4 = (RelativeLayout) v.findViewById(R.id.amazon4);
	     amazon4.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.amazonvalue4),getString(R.string.amazontitle4),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     
	     
	     

	     
	     RelativeLayout google1 = (RelativeLayout) v.findViewById(R.id.google1);
	     google1.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.googlevalue1),getString(R.string.googletitle1),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	        
	     RelativeLayout google2 = (RelativeLayout) v.findViewById(R.id.google2);
	     google2.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.googlevalue2),getString(R.string.googletitle2),String.valueOf(UserProfile.getid()));
	            	
	            }
	        }); 
	     
	     RelativeLayout google3 = (RelativeLayout) v.findViewById(R.id.google3);
	     google3.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.googlevalue3),getString(R.string.googletitle3),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout google4 = (RelativeLayout) v.findViewById(R.id.google4);
	     google4.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.googlevalue4),getString(R.string.googletitle4),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     
	     RelativeLayout xbox1 = (RelativeLayout) v.findViewById(R.id.xbox1);
	     xbox1.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.xboxvalue1),getString(R.string.xboxtitle1),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	        
	     RelativeLayout xbox2 = (RelativeLayout) v.findViewById(R.id.xbox2);
	     xbox2.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.xboxvalue2),getString(R.string.xboxtitle2),String.valueOf(UserProfile.getid()));
	            	
	            }
	        }); 
	     
	     RelativeLayout xbox3 = (RelativeLayout) v.findViewById(R.id.xbox3);
	     xbox3.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {
	            	StartRoutine(getString(R.string.xboxvalue3),getString(R.string.xboxtitle3),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     RelativeLayout xbox4 = (RelativeLayout) v.findViewById(R.id.xbox4);
	     xbox4.setOnClickListener(new View.OnClickListener() 
	        {
	            @Override
	            public void onClick(View v) 
	            {StartRoutine(getString(R.string.xboxvalue4),getString(R.string.xboxtitle4),String.valueOf(UserProfile.getid()));
	            }
	        }); 
	     
	        return v;    
	}

    
       
    public void StartRoutine(final String value1x,final String value2x,final String value3x){
      	 LayoutInflater inflater = getActivity().getLayoutInflater();
      	 final String value1=value1x;
      	 final String value2=value2x;
      	 final String value3=value3x;
   	        View layout = inflater.inflate(R.layout.dialog_paypal,null);
   		 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
   				mycontxt, R.style.AlertDialogCustom);
   		 final EditText editTextEmailx = (EditText) layout.findViewById(R.id.editTextEmail);
   		 Button RegisterButtonx = (Button) layout.findViewById(R.id.RegisterButtonx);
   		 Typeface ItemFont = Typeface.createFromAsset(getActivity().getAssets(),"BebasNeue Regular.otf"); 
		   Typeface BoldFont = Typeface.createFromAsset(getActivity().getAssets(),"BebasNeue Bold.otf"); 
		   editTextEmailx.setTypeface(BoldFont);
		 
		   RegisterButtonx.setTypeface(ItemFont);
   		 if (value2.contains("PayPal")) {
   			editTextEmailx.setHint("Your Paypal Adress");
   		 }else {

    	editTextEmailx.setHint("Your Email Adress");
   		 }
   		 
   		if (value2.contains("Recharge")) {

   	    	editTextEmailx.setHint("Your Phone Number");
   			 
   		 }
   		
   				alertDialogBuilder
   					.setView(layout)
   					.setCancelable(true);
   					final AlertDialog alertDialog = alertDialogBuilder.create();
   					   RegisterButtonx.setOnClickListener(new OnClickListener() {
   							 @Override
   							public void onClick(View view) {
   								 if(!editTextEmailx.getText().toString().matches(""))
   								 {    alertDialog.dismiss();
   								ShowProgress(getString(R.string.Checkout));
    								Log.e("value1",value1x);
       								Log.e("value2",value2x);
       								Log.e("value3",value3x);
   				            	CheckoutNow(value1,value2,value3,value2+" to "+editTextEmailx.getText().toString());
   							    }else { 
   									 ShowError(getString(R.string.Fillfields));
   									   }
   							 }
   			        	 });
   					// show it
   					alertDialog.show();
   				}
       
  
  public void CheckoutNow(final String cost,final String dollar, final String userid, final String paypal) {
	 MyRestClient.APICONTROL.Checkout(cost,dollar,userid, paypal, new Callback<JsonElement>() {
	        @Override
	        public void success(JsonElement s, Response response) {
	        	ProgressToast.dismiss();
	        	JsonObject jsonObj = s.getAsJsonObject();
	        	String strObj = jsonObj.toString();
	        	//process your response if login successfull you can call Intent and launch your main activity
	        	
	        		  	String StatusCode = MyRestClient.StatusParser(strObj);
		        	String Message = MyRestClient.MessageParser(strObj);
		         if(StatusCode.matches("200")){
		        		Log.e("CheckoutResponnse",StatusCode+":"+Message);
		        		ShowGood(Message);
					}
					else {
						Log.e("CheckoutResponnse Error",StatusCode+":"+Message);

		        		ShowError(Message);
					}
	        }
	        @Override
	        public void failure(RetrofitError retrofitError) {
	        	ProgressToast.dismiss();
	            retrofitError.printStackTrace(); //to see if you have errors
		        String StatusCode = null;String Message = null; 
	            try {
		            	String GetResponse = new String(((TypedByteArray) retrofitError.getResponse().getBody()).getBytes());
		            	 StatusCode = MyRestClient.StatusParser(GetResponse);
		            	 Message= MyRestClient.MessageParser(GetResponse);

	            		 Log.e("Login Status","Fail");
		            	 
		            }
		            catch (Exception e) {// NOT JSON, CANT PARSE IT.

		            	Log.e("Response Error","Bad Json");
		            }	
	            	
	            	if ( (StatusCode!=null) && (Message!=null)) {
	            	ShowError(Message);
//	            	 ShowForm(true);
           		}else { // NOT JSON, CANT PARSE IT.
          			ShowError(getString(R.string.ourerror));
//            			 ShowForm(true);
            		}
					
				}
	 		});  
	    }
 
  public void ShowProgress(String msgId){
  	ProgressToast = new SuperCardToast(this.getActivity(), SuperToast.Type.PROGRESS);
    	ProgressToast.setText(msgId);
   	ProgressToast.setBackground(SuperToast.Background.BLUE);
   	ProgressToast.setTextColor(Color.WHITE);
   	//ProgressToast.setDuration(SuperToast.Duration.LONG);
   	ProgressToast.setIndeterminate(true);
   	ProgressToast.setProgressIndeterminate(true);
   	ProgressToast.setSwipeToDismiss(true);
   	ProgressToast.setTouchToDismiss(true);
   	ProgressToast.show();
        
  }

public void ShowError(String Message){

	   // Toast.makeText(this.getActivity()(), ErrorPhrase, Toast.LENGTH_LONG).show();
	   SuperCardToast superCardToast = new SuperCardToast(this.getActivity());
	  superCardToast.setText(Message);
	  superCardToast.setDuration(SuperToast.Duration.EXTRA_LONG);
	  superCardToast.setBackground(SuperToast.Background.RED);
	  superCardToast.setTextColor(Color.WHITE);
	  superCardToast.setSwipeToDismiss(true);
 		superCardToast.setTouchToDismiss(true);
	  superCardToast.show();
 }

public void ShowGood(String msgId){
	final SuperCardToast superCardToast = new SuperCardToast(this.getActivity(), SuperToast.Type.STANDARD);
	superCardToast.setText(msgId);
	superCardToast.setBackground(SuperToast.Background.GREEN);
	superCardToast.setIcon(SuperToast.Icon.Dark.INFO, SuperToast.IconPosition.LEFT);
	superCardToast.setTextColor(Color.WHITE);
	superCardToast.setIndeterminate(true);
	superCardToast.setTouchToDismiss(true);
	superCardToast.setSwipeToDismiss(true);
	superCardToast.show();
}
}
