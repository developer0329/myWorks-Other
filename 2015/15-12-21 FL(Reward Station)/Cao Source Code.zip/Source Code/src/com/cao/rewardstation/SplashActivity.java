package com.cao.rewardstation;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.github.johnpersano.supertoasts.SuperCardToast;
import com.github.johnpersano.supertoasts.SuperToast;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;


public class SplashActivity extends Activity {
	SuperCardToast ProgressToast;
	private static int SPLASH_TIME_OUT = 1000;
	 EditText editTextEmail,editTextPassword;String Email,Password;
	 Button RegisterButton;Button LoginButton;TextView ForgotTextView;
	 RestClient MyRestClient;static Context context;
		private Handler mHandler = new Handler();

	    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        SuperCardToast.onRestoreState(savedInstanceState, SplashActivity.this);
        editTextEmail = (EditText)findViewById(R.id.editTextEmail);
        
        editTextPassword = (EditText)findViewById(R.id.editTextPassword);	
        context = getApplicationContext();
        MyRestClient = new RestClient();
        
        LoginButton = (Button)findViewById(R.id.LoginButton);
		LoginButton.setOnClickListener(new OnClickListener() {
			 @Override
			public void onClick(View view) {
			
				 if ((editTextEmail.getText().toString()!="" ) && (editTextPassword.getText().toString()!="" ) ) {
					 Calendar calendar = Calendar.getInstance();
					 int day = calendar.get(Calendar.DAY_OF_WEEK); 
					 
					 if ( day==1){
					 ShowProgress(R.string.LoginString);	
					 Login(editTextEmail.getText().toString(), editTextPassword.getText().toString());
						
					 }else {
					 Login(editTextEmail.getText().toString(), editTextPassword.getText().toString());
					 ShowProgress(R.string.LoginString);	 
					 }
				 } else {
					 Log.e("Error","Email or Password Empty");
					 ShowError("003",getString(R.string.Fillfields));
				 }
				 }
			});

		
		RegisterButton = (Button)findViewById(R.id.RegisterButton);
		RegisterButton.setOnClickListener(new OnClickListener() {
			 @Override
			public void onClick(View view) {
				 StartRegister(null);

			 }
			});
		
	

ForgotTextView = (TextView)findViewById(R.id.ForgotText);
		ForgotTextView.setOnClickListener(new OnClickListener() {
			 @Override
			public void onClick(View view) {
				 StartReset("");
	            //	ShowGood(getString(R.string.demo));
			 }
			});

		  
		   Typeface ItemFont = Typeface.createFromAsset(context.getAssets(),"BebasNeue Regular.otf"); 
		   Typeface BoldFont = Typeface.createFromAsset(context.getAssets(),"BebasNeue Bold.otf"); 
	       editTextEmail.setTypeface(BoldFont);
	       editTextPassword.setTypeface(BoldFont);
	       RegisterButton.setTypeface(BoldFont);
	       LoginButton.setTypeface(BoldFont);
	       
	       ForgotTextView.setTypeface(ItemFont);
        DoChecks();
    }

	
	



 public void StartReset(String Error){
      	if (editTextEmail.getText().toString().matches("")){
      		ShowError("400","Please input your Email first !");
      		}
      	else {
      		 ShowProgress(R.string.reset);
      		Reset(editTextEmail.getText().toString());
      	}
    }
       
    
    public void Reset(final String email) {


	 MyRestClient.APICONTROL.reset(email,new Callback<JsonElement>() {
		 
	        @Override
	        public void success(JsonElement s, Response response) {
	        	ProgressToast.dismiss();	
	           	JsonObject jsonObj = s.getAsJsonObject();
        	String strObj = jsonObj.toString();
        	Log.e("Success",strObj);
        	String StatusCode = MyRestClient.StatusParser(strObj);
        	String Message = MyRestClient.MessageParser(strObj);
        	Log.e("ResetResponse",StatusCode+":"+Message);
        	 if(StatusCode.matches("200")){
				 ShowGood(Message);
        	 }else {
        		 Log.e("Reset Status","Failed");
				 ShowError("003",getString(R.string.ourerror));
        	 }
          	
	        }
	        @Override
	        public void failure(RetrofitError retrofitError) {
	        	ProgressToast.dismiss();	
	            retrofitError.printStackTrace(); //to see if you have errors
		        String StatusCode = null;String Message = null; 
	            try {
		            	String GetResponse = new String(((TypedByteArray) retrofitError.getResponse().getBody()).getBytes());
		            	 StatusCode = MyRestClient.StatusParser(GetResponse);
		            	 Message= MyRestClient.MessageParser(GetResponse);

	            		 Log.e("Login Status","Fail");
		            	 
		            }
		            catch (Exception e) {// NOT JSON, CANT PARSE IT.

		            	Log.e("Response Error","Bad Json");
		            }	
	            	
	            	if ( (StatusCode!=null) && (Message!=null)) {
          	ShowError(StatusCode,Message);
	            	// ShowForm(true);
         		}else { // NOT JSON, CANT PARSE IT.
          			ShowError("XXX",getString(R.string.ourerror));
         			// ShowForm(true);
          		}
					
				}
	 			});  
	          }
			  
    public void StartRegister(String Error){
   	 LayoutInflater inflater = getLayoutInflater();
   	 
	        View layout = inflater.inflate(R.layout.dialog_register,null);
		 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				 SplashActivity.this, R.style.AlertDialogCustom);
		 final EditText editTextEmailx = (EditText) layout.findViewById(R.id.editTextEmail);
		 final EditText editTextUsernamex = (EditText) layout.findViewById(R.id.editTextUsername);
		 final EditText editTextPasswordx = (EditText) layout.findViewById(R.id.editTextPassword);

		 final EditText editTextReferral = (EditText) layout.findViewById(R.id.editTextReferral);	
		 Button RegisterButtonx = (Button) layout.findViewById(R.id.RegisterButtonx);
		 
		  Typeface ItemFont = Typeface.createFromAsset(context.getAssets(),"BebasNeue Regular.otf"); 
		   Typeface BoldFont = Typeface.createFromAsset(context.getAssets(),"BebasNeue Bold.otf"); 
		   editTextEmailx.setTypeface(BoldFont);
		   editTextUsernamex.setTypeface(BoldFont);
		   editTextPasswordx.setTypeface(BoldFont);
		   editTextReferral.setTypeface(BoldFont);
		   RegisterButtonx.setTypeface(ItemFont);
		   
			 if (Error != null){
				 //Make Error visibile
     			ShowError("XXX",Error);
			 }
		 		 
				alertDialogBuilder
					.setView(layout)
					.setCancelable(true);
					final AlertDialog alertDialog = alertDialogBuilder.create();
					   RegisterButtonx.setOnClickListener(new OnClickListener() {
							 @Override
							public void onClick(View view) {
								 if((!editTextUsernamex.getText().toString().matches("")) && (!editTextEmailx.getText().toString().matches("")) && (!editTextPasswordx.getText().toString().matches("")))
								 {    alertDialog.dismiss();
								 TelephonyManager tm = (TelephonyManager)getApplicationContext().getSystemService(getApplicationContext().TELEPHONY_SERVICE);
							        String countryCodeValue = tm.getNetworkCountryIso();
							        
							        ShowProgress(R.string.RegisterString);

							        try {
										byte[] data = countryCodeValue.getBytes("UTF-8");
									} catch (UnsupportedEncodingException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
							        	countryCodeValue="pa";
									}
							        
							        if (countryCodeValue.isEmpty()){
							        	countryCodeValue="pa";
							        }
							        String devid = "";
							        Register(editTextUsernamex.getText().toString(),editTextEmailx.getText().toString(),editTextPasswordx.getText().toString(),countryCodeValue,editTextReferral.getText().toString(),devid);
								 }else { 
									 ShowError("003",getString(R.string.Fillfields));
									   }
							 }
			        	 });
					// show it
					alertDialog.show();
				}
    
    public void Register(final String username,final String email,final String password,final String country, final String referral,final String devid) {
    	ProgressToast.dismiss();	 
    	MyRestClient.APICONTROL.register(username,email,password,country,referral,devid,new Callback<JsonElement>() {
    		        @Override
    		        public void success(JsonElement s, Response response) {
    		        	JsonObject jsonObj = s.getAsJsonObject();
    		        	String strObj = jsonObj.toString();
    		        	Log.e("Success",strObj);
    		        	String StatusCode = MyRestClient.StatusParser(strObj);
    		        	String Message = MyRestClient.MessageParser(strObj);
    		        	Log.e("RegisterResponse",StatusCode+":"+Message);
    		        	 if(StatusCode.matches("200")){
    	            		 Log.e("Register Status","Success");
    	            		 editTextEmail.setText(email);
    	            		 editTextPassword.setText(password);
							 ShowGood(getString(R.string.registerok));
    	            	 }else {
    	            		 Log.e("Register Status","Failed");
							 ShowError("003",getString(R.string.ourerror));
    	            	 }
    		        	
    		        }
    		        @Override
    		        public void failure(RetrofitError retrofitError) {
    		            System.out.println("Failure, retrofitError" + retrofitError);
    		            retrofitError.printStackTrace(); //to see if you have errors
    			        String StatusCode = null;String Message = null; 
    		            try {
    			            	String GetResponse = new String(((TypedByteArray) retrofitError.getResponse().getBody()).getBytes());

    				        	 Log.e("Failure",GetResponse);
    			            	StatusCode = MyRestClient.StatusParser(GetResponse);
    			            	 Message= MyRestClient.MessageParser(GetResponse);
    			            	 Log.e("Register Status","Fail");
    			            
    			            	 }
    			            
    			            catch (Exception e) {// NOT JSON, CANT PARSE IT.

    			            	Log.e("Response Error","Bad Json");
    			            }	
    		            	
    		            	if ( (StatusCode!=null) && (Message!=null)) {
    	            			StartRegister(Message);
    	            		}else { // NOT JSON, CANT PARSE IT.
    	            			StartRegister(getString(R.string.ourerror));
    	            			
    	            		}
    						
    					}
    		    });  
    	 	
    }

    public void Login(final String email,final String password) {

		  mHandler.postDelayed(new Runnable() {
	            public void run() {
	            	ProgressToast.dismiss();	 
	            	
	 MyRestClient.APICONTROL.login(email,password,new Callback<JsonElement>() {
	        @Override
	        public void success(JsonElement s, Response response) {
	        	JsonObject jsonObj = s.getAsJsonObject();
	        	String strObj = jsonObj.toString();
	        	//process your response if login successfull you can call Intent and launch your main activity
	        	
	        		 String id =  MyRestClient.XParser(strObj,"id");
	        		 String name =  MyRestClient.XParser(strObj,"name");
	        		 String email =  MyRestClient.XParser(strObj,"email");
	        		 String country =  MyRestClient.XParser(strObj,"country");
	        		 String credits =  MyRestClient.XParser(strObj,"credits");
	        		 String refs =  MyRestClient.XParser(strObj,"refs");
	        		 String ip = MyRestClient.XParser(strObj,"ip");
	        		 Log.e("IP ADRESS",ip);
	        		 int NotifNumber=0;
	        		 
	        		 String notifs = MyRestClient.XParser(strObj,"notifications");
	        		 if(notifs.length()>3){
	        			 JsonObject requestobject = jsonObj.getAsJsonObject("request");
	        			 JsonArray NotifArray = requestobject.getAsJsonArray("notifications");
		        		 int len = NotifArray.size();
		        		 NotifNumber=len;
		        		 for(int i = 0; i < len; ++i) {
		 	        		JsonObject objd = NotifArray.get(i).getAsJsonObject();
		 	        		 String notificon = MyRestClient.YParser(objd.toString(),"icon").replace("^", "");
		 	        		 String notifmessage = MyRestClient.YParser(objd.toString(),"message");
		 	        		 String notifurl = MyRestClient.YParser(objd.toString(),"link");
		 	        		
		 	        		 Log.e("Notif Final",notificon+"^"+notifmessage+"^"+notifurl);
		 	        		}
	        		 }
            		 User UserProfile = new User(Integer.parseInt(id),name,email,Float.parseFloat(credits),country,Integer.parseInt(refs),"paypal",NotifNumber,ip);
            		 savePreferences("Email",email);
            		 savePreferences("Password",password);
            		 StartIntent(UserProfile);
            	
	        }
	        @Override
	        public void failure(RetrofitError retrofitError) {
	            retrofitError.printStackTrace(); //to see if you have errors
		        String StatusCode = null;String Message = null; 
	            try {
		            	String GetResponse = new String(((TypedByteArray) retrofitError.getResponse().getBody()).getBytes());
		            	 StatusCode = MyRestClient.StatusParser(GetResponse);
		            	 Message= MyRestClient.MessageParser(GetResponse);

	            		 Log.e("Login Status","Fail");
		            	 
		            }
		            catch (Exception e) {// NOT JSON, CANT PARSE IT.

		            	Log.e("Response Error","Bad Json");
		            }	
	            	
	            	if ( (StatusCode!=null) && (Message!=null)) {
            	ShowError(StatusCode,Message);
	            	// ShowForm(true);
           		}else { // NOT JSON, CANT PARSE IT.
            			ShowError("XXX",getString(R.string.ourerror));
           			// ShowForm(true);
            		}
					
				}
	    });  
	          }
	        }, 1000);
 }
    
    public void DoChecks(){
		 
    	if (hasConnection()){
        	Log.e("Connected to Internet","TRUE");
        		 if (hasLoggedIn()){
		        		Log.e("Has Logged In","TRUE : "+Email+":"+Password);
		        		editTextEmail.setText(Email);
		        		editTextPassword.setText(Password);
		        		//Login(Email,Password);
		        	       		}
        		 else {
		        		Log.e("Has Logged In","FALSE");
		        		//ShowForm(true);
		        		}
        	 }
        else {
        	Log.e("Connected to Internet","FALSE");
        	  }
}
    
    public boolean hasLoggedIn() {
    	SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
     	String Emailx = preferences.getString("Email", "");
     	String Passwordx = preferences.getString("Password", "");
    	if((!Emailx.equalsIgnoreCase("")) && (!Passwordx.equalsIgnoreCase("")) )
    	{
    		Email = Emailx;
    		Password = Passwordx ;
    	  return true;
    	  
    	}
    	
    	return false;
    }
        
    
    public static boolean hasConnection() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(
            Context.CONNECTIVITY_SERVICE);

        NetworkInfo wifiNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiNetwork != null && wifiNetwork.isConnected()) {
          return true;
        }

        NetworkInfo mobileNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (mobileNetwork != null && mobileNetwork.isConnected()) {
          return true;
        }

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnected()) {
          return true;
        }

        return false;
      }
    public void StartIntent(User UserProfile){
   	 Intent intent = new Intent(SplashActivity.this, MainActivity.class);
	 intent.putExtra("UserProfile", UserProfile);
		 startActivity(intent);
		 finish();
   }
    
    private void savePreferences(String key, String value) {
    	    SharedPreferences sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(this);
      Editor editor = sharedPreferences.edit();
    	    editor.putString(key, value);
    	     editor.commit();
    	
    	    }
    
    
    
    public void ShowProgress(final int msgId){
    	ProgressToast = new SuperCardToast(SplashActivity.this, SuperToast.Type.PROGRESS);
      	ProgressToast.setText(getString(msgId));
     	ProgressToast.setBackground(SuperToast.Background.BLUE);
     	ProgressToast.setTextColor(Color.WHITE);
     	ProgressToast.setIndeterminate(true);
     	ProgressToast.setProgressIndeterminate(true);
     	ProgressToast.show();
          
    }
    public void ShowError(String StatusCode,String Message){
		 String ErrorPhrase = Message;
		 Log.e("ShowError",ErrorPhrase);
	   SuperCardToast superCardToast = new SuperCardToast(SplashActivity.this);
	  superCardToast.setText(Message);
	  superCardToast.setDuration(SuperToast.Duration.EXTRA_LONG);
	  superCardToast.setBackground(SuperToast.Background.RED);
	  superCardToast.setTextColor(Color.WHITE);
	  superCardToast.setSwipeToDismiss(true);
	  superCardToast.show();
   }


    
    public void ShowGood(String msgId){
    	final SuperCardToast superCardToast = new SuperCardToast(this, SuperToast.Type.STANDARD);
    	superCardToast.setText(msgId);
    	superCardToast.setBackground(SuperToast.Background.GREEN);
    	superCardToast.setIcon(SuperToast.Icon.Dark.INFO, SuperToast.IconPosition.LEFT);
    	superCardToast.setTextColor(Color.WHITE);
    	superCardToast.setDuration(SuperToast.Duration.LONG);
    	superCardToast.setTouchToDismiss(true);
    	superCardToast.setSwipeToDismiss(true);
    	superCardToast.show();
    }
}
