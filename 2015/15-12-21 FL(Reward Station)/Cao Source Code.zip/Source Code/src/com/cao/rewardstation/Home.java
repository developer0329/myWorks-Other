package com.cao.rewardstation;


import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.johnpersano.supertoasts.SuperCardToast;
import com.github.johnpersano.supertoasts.SuperToast;

public class Home extends Fragment  implements OnRefreshListener{
	 SuperCardToast ProgressToast;
	 String pubid,apikey,userip,userid,completed,extraparams;
	 String OffersUrl;
	 User UserProfile;
	 Context mycontxt;
	 MainActivity activity;
View v;
		RestClient MyRestClient;
	 
	@Override
	 public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
	         v =inflater.inflate(R.layout.home,container,false);
	        //SuperCardToast.onRestoreState(savedInstanceState, this.getActivity());
		        final ViewGroup containerx = container;

		    UserProfile =  ((MainActivity) this.getActivity()).getUserProfile();
	    	ProgressToast = new SuperCardToast(this.getActivity(), SuperToast.Type.PROGRESS);
	        mycontxt=getActivity().getApplicationContext();
	        pubid= getString(R.string.pubid);
	        MyRestClient = ((MainActivity)this.getActivity()).getClient();
	        apikey= getString(R.string.apikey);
	        userip= UserProfile.getip();
	        userid= String.valueOf(UserProfile.getid());

	        Create_Layout();
	     
	        
	        // AdscendMedia
    		CardView Network1 = (CardView) v.findViewById(R.id.NetworkButton1);
    		Network1.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
				 Intent intent = new Intent(getActivity(), AdscendActivity.class);
				 intent.putExtra("UserProfile", UserProfile);
					 startActivity(intent);
//					 finish();
	        	
//				Intent myIntent = new Intent(getActivity(), OfferWall.class);
//				String url = getString(R.string.adscend)+String.valueOf(UserProfile.getid());
//				myIntent.putExtra("url", url); //Optional parameters
//				getActivity().startActivity(myIntent);
	        	
	        }
	        });
    		
	        // NativeX
    		CardView Network2 = (CardView) v.findViewById(R.id.NetworkButton2);
    		Network2.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	        	((MainActivity) getActivity()).shownativex();
	        }
	        });
    		

    		
	        // AdColony
    		CardView Network3 = (CardView) v.findViewById(R.id.NetworkButton3);
    		Network3.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	        	((MainActivity) getActivity()).ShowAdColony();	        	
	        }
	        });
    		
    		
    		 // CpaLead
    		CardView Network4 = (CardView) v.findViewById(R.id.NetworkButton4);
    		Network4.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
				Intent myIntent = new Intent(getActivity(), OfferWall.class);
				String url = getString(R.string.cpalead)+"&subid="+String.valueOf(UserProfile.getid());
				
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
				startActivity(browserIntent);
				
//				myIntent.putExtra("url", url); //Optional parameters
//				getActivity().startActivity(myIntent);
	        }
	        });
    		
    		// AdworkMedia
	   		CardView Network5 = (CardView) v.findViewById(R.id.NetworkButton5);
	   		Network5.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
				Intent myIntent = new Intent(getActivity(), OfferWall.class);
				String url = getString(R.string.adwork)+"/"+String.valueOf(UserProfile.getid());
				
//				Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
//				startActivity(browserIntent);
				
			 	myIntent.putExtra("url", url); //Optional parameters
				getActivity().startActivity(myIntent);
	        }
	        });
    		
    		// Woobi
	   		CardView Network6 = (CardView) v.findViewById(R.id.NetworkButton6);
	   		Network6.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	        	Intent myIntent = new Intent(getActivity(), OfferWall.class);
			String url = getString(R.string.woobi)+String.valueOf(UserProfile.getid());
			
			Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
			startActivity(browserIntent);
			
//			myIntent.putExtra("url", url); //Optional parameters
//			getActivity().startActivity(myIntent);
	        	
	        }
	        });

	   		// AdGateMedia
	   		CardView Network7 = (CardView) v.findViewById(R.id.NetworkButton7);
	   		Network7.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	    		Intent myIntent = new Intent(getActivity(), OfferWall.class);
	    		
		        String url = getString(R.string.adgate)+"/"+String.valueOf(UserProfile.getid());
			 	myIntent.putExtra("url", url); //Optional parameters
					getActivity().startActivity(myIntent);
		
	        }
	        });

	   		// Facebook Referral
	   		CardView Network8 = (CardView) v.findViewById(R.id.NetworkButton8);
	   		Network8.setOnClickListener(new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	        	Intent share = new Intent(android.content.Intent.ACTION_SEND);
				 share.setType("text/plain");
					share.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id="+getActivity().getApplicationContext().getPackageName());

					getActivity().startActivity(Intent.createChooser(share, "Share your Invitation link"));
				
	        }
	        });

//	        CardView Share = (CardView) v.findViewById(R.id.Share);
//	        Share.setOnClickListener(new View.OnClickListener() {
//	            @Override
//	            public void onClick(View v) {
//	            	Intent sharex = new Intent(android.content.Intent.ACTION_SEND);
//           		sharex.setType("text/plain");
//					sharex.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id="+getActivity().getApplicationContext().getPackageName());
//					getActivity().startActivity(Intent.createChooser(sharex, "Share your Invitation link"));
//					
//	            }
//	            
//	            
//	        });
//	        
//	    		CardView cpalead = (CardView) v.findViewById(R.id.cpalead);
//		        cpalead.setOnClickListener(new View.OnClickListener() {
//		        @Override
//		        public void onClick(View v) {
//
//				Intent myIntent = new Intent(getActivity(), OfferWall.class);
//				String url = getString(R.string.cpalead)+"&subid="+String.valueOf(UserProfile.getid());
//				myIntent.putExtra("url", url); //Optional parameters
//				getActivity().startActivity(myIntent);
//		        }
//		        });
//		        
//
//		        CardView woobi = (CardView) v.findViewById(R.id.woobi);
//		        woobi.setOnClickListener(new View.OnClickListener() {
//		        @Override
//		        public void onClick(View v) {
//
//				Intent myIntent = new Intent(getActivity(), OfferWall.class);
//				String url = getString(R.string.woobi)+String.valueOf(UserProfile.getid());
//				myIntent.putExtra("url", url); //Optional parameters
//				getActivity().startActivity(myIntent);
//		        }
//		        });
//	    		CardView adgate = (CardView) v.findViewById(R.id.AdGateMedia);
//	    		adgate.setOnClickListener(new View.OnClickListener() {
//		        @Override
//		        public void onClick(View v) {
//		        String url = getString(R.string.adgate)+"/"+String.valueOf(UserProfile.getid());
//				Intent i = new Intent(Intent.ACTION_VIEW);
//				i.setData(Uri.parse(url));
//				startActivity(i);
//				
//		        }
//		        });
//	    		
//	    		 
//	    		CardView superrewards = (CardView) v.findViewById(R.id.superrewards);
//	    		superrewards.setOnClickListener(new View.OnClickListener() {
//		        @Override
//		        public void onClick(View v) {
//
//				Intent myIntent = new Intent(getActivity(), OfferWall.class);
//				String url = getString(R.string.superrewards)+"&uid="+String.valueOf(UserProfile.getid());
//				myIntent.putExtra("url", url); //Optional parameters
//				getActivity().startActivity(myIntent);
//		        }
//		        });
//		        
//		        CardView adwork = (CardView) v.findViewById(R.id.adwork);
//		        adwork.setOnClickListener(new View.OnClickListener() {
//		        @Override public void onClick(View v) {
//				Intent myIntent = new Intent(getActivity(), OfferWall.class);
//				String url = getString(R.string.adwork)+"/"+String.valueOf(UserProfile.getid());
//			 	myIntent.putExtra("url", url); //Optional parameters
//				getActivity().startActivity(myIntent);
//
//		        }
//		        });
//		        CardView nativex = (CardView) v.findViewById(R.id.nativex);
//		        nativex.setOnClickListener(new View.OnClickListener() {
//		        @Override public void onClick(View v) {
//		        	//InterstitialManager.showInterstitial(mycontxt, getString(R.string.appnextID), InterstitialManager.REWARDED_VIDEO);
//		        	((MainActivity) getActivity()).shownativex();
//		        }
//		        });
//		        
//		        CardView appnext = (CardView) v.findViewById(R.id.appnext);
//		        appnext.setOnClickListener(new View.OnClickListener() {
//		        @Override public void onClick(View v) {
//		        	//InterstitialManager.showInterstitial(mycontxt, getString(R.string.appnextID), InterstitialManager.REWARDED_VIDEO);
//		        	((MainActivity) getActivity()).ShowAppNext();
//		        }
//		        });
//		        
//		        InterstitialManager.setOnVideoEndedCallback(new OnVideoEnded() {
//		        	@Override
//		        	public void videoEnded() {
//		        		Log.e("AppNext","CALLED BACK");
//				     //   GetAppNext();
//		        	}
//		        	});
//		        
//		        CardView adscend = (CardView) v.findViewById(R.id.adscend);
//		        adscend.setOnClickListener(new View.OnClickListener() {
//		        @Override
//		        public void onClick(View v) {
//
//				Intent myIntent = new Intent(getActivity(), OfferWall.class);
//				String url = getString(R.string.adscend)+String.valueOf(UserProfile.getid());
//				myIntent.putExtra("url", url); //Optional parameters
//				getActivity().startActivity(myIntent);
//		        }
//		        });
//		        
//		        
//		        CardView personaly = (CardView) v.findViewById(R.id.personaly);
//		        personaly.setOnClickListener(new View.OnClickListener() {
//		        @Override
//		        public void onClick(View v) {
//
//		        	PersonaSdk.showOffers();
//		        }
//		        });
	        return v;    
	}
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
	}
   
	  public void ShowProgress(String msgId){
	    	ProgressToast = new SuperCardToast(this.getActivity(), SuperToast.Type.PROGRESS);
	      	ProgressToast.setText(msgId);
	     	ProgressToast.setBackground(SuperToast.Background.BLUE);
	     	ProgressToast.setTextColor(Color.WHITE);
	     	//ProgressToast.setDuration(SuperToast.Duration.LONG);
	     	ProgressToast.setIndeterminate(true);
	     	ProgressToast.setProgressIndeterminate(true);
	     	ProgressToast.setSwipeToDismiss(true);
	     	ProgressToast.setTouchToDismiss(true);
	     	ProgressToast.show();
	          
	    }
	  
	 public void ShowError(String Message){

		   // Toast.makeText(this.getActivity()(), ErrorPhrase, Toast.LENGTH_LONG).show();
		   SuperCardToast superCardToast = new SuperCardToast(this.getActivity());
		  superCardToast.setText(Message);
		  superCardToast.setDuration(SuperToast.Duration.EXTRA_LONG);
		  superCardToast.setBackground(SuperToast.Background.RED);
		  superCardToast.setTextColor(Color.WHITE);
		  superCardToast.setSwipeToDismiss(true);
	   		superCardToast.setTouchToDismiss(true);
		  superCardToast.show();
	   }
	 
   public void ShowGood(String msgId){
   	final SuperCardToast superCardToast = new SuperCardToast(this.getActivity(), SuperToast.Type.STANDARD);
     	superCardToast.setText(msgId);
    	superCardToast.setBackground(SuperToast.Background.GREEN);
    	superCardToast.setIcon(SuperToast.Icon.Dark.INFO, SuperToast.IconPosition.LEFT);
    	superCardToast.setTextColor(Color.WHITE);
    	superCardToast.setDuration(SuperToast.Duration.LONG);
    	superCardToast.setTouchToDismiss(true);
    	superCardToast.show();
   }
   
 

   
   public void Create_Layout(){
	   
	     // Define TypeFaces
	   Typeface NetworkFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Regular.otf"); 
	   Typeface TitleFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Bold.otf"); 
		   Typeface  PageFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Bold.otf"); 
	   TextView   PageTitle = (TextView) v.findViewById(R.id.PageTextView);

	   PageTitle.setTypeface(PageFont);
	   
	   TextView   Title = (TextView) v.findViewById(R.id.TitleTextView);
	   TextView   ButtonText = (TextView) v.findViewById(R.id.buttontext);
	   TextView   RulesTextw = (TextView) v.findViewById(R.id.Rules1w);
	   TextView   RulesTextx = (TextView) v.findViewById(R.id.Rules1x);
	   TextView   RulesTexty = (TextView) v.findViewById(R.id.Rules1y);
	   TextView   RulesTextz = (TextView) v.findViewById(R.id.Rules1z);
	   

	   TextView   RulesText2w = (TextView) v.findViewById(R.id.Rules2w);
	   TextView   RulesText2x = (TextView) v.findViewById(R.id.Rules2x);
	   TextView   RulesText2y = (TextView) v.findViewById(R.id.Rules2y);
	  // TextView   RulesText2z = (TextView) v.findViewById(R.id.Rules2z);
	   

	   TextView   RulesText3w = (TextView) v.findViewById(R.id.Rules3w);
	   TextView   RulesText3x = (TextView) v.findViewById(R.id.Rules3x);
	   TextView   RulesText3y = (TextView) v.findViewById(R.id.Rules3y);
	  // TextView   RulesText3z = (TextView) v.findViewById(R.id.Rules3z);
	   

	   TextView   RulesText4w = (TextView) v.findViewById(R.id.Rules4w);
	   TextView   RulesText4x = (TextView) v.findViewById(R.id.Rules4x);
	   TextView   RulesText4y = (TextView) v.findViewById(R.id.Rules4y);
	   TextView   RulesText4z = (TextView) v.findViewById(R.id.Rules4z);
	   

	   TextView   RulesText5w = (TextView) v.findViewById(R.id.Rules5w);
	   TextView   RulesText5x = (TextView) v.findViewById(R.id.Rules5x);
	   TextView   RulesText5y = (TextView) v.findViewById(R.id.Rules5y);
	   TextView   RulesText5z = (TextView) v.findViewById(R.id.Rules5z);

	   TextView   RulesText6w = (TextView) v.findViewById(R.id.Rules6w);
	   TextView   RulesText6x = (TextView) v.findViewById(R.id.Rules6x);
	   TextView   RulesText6y = (TextView) v.findViewById(R.id.Rules6y);
	   TextView   RulesText6z = (TextView) v.findViewById(R.id.Rules6z);

	   TextView   RulesText7w = (TextView) v.findViewById(R.id.Rules7w);
	   TextView   RulesText7x = (TextView) v.findViewById(R.id.Rules7x);
	   TextView   RulesText7y = (TextView) v.findViewById(R.id.Rules7y);
	   TextView   RulesText7z = (TextView) v.findViewById(R.id.Rules7z);
	   

	   TextView   RulesText8 = (TextView) v.findViewById(R.id.Rules8x);
	   
	   TextView   Title2 = (TextView) v.findViewById(R.id.TitleTextView2);
	   TextView   ButtonText2 = (TextView) v.findViewById(R.id.buttontext2);
	//   TextView   RulesText2 = (TextView) v.findViewById(R.id.Rules2);
  
	   TextView    Title3 = (TextView) v.findViewById(R.id.TitleTextView3);
	   TextView    ButtonText3 = (TextView) v.findViewById(R.id.buttontext3);


	   TextView    Title4 = (TextView) v.findViewById(R.id.TitleTextView4);
	   TextView    ButtonText4 = (TextView) v.findViewById(R.id.buttontext4);
	   

	   TextView    Title5 = (TextView) v.findViewById(R.id.TitleTextView5);
	   TextView    ButtonText5 = (TextView) v.findViewById(R.id.buttontext5);


	   TextView    Title6 = (TextView) v.findViewById(R.id.TitleTextView6);
	   TextView    ButtonText6 = (TextView) v.findViewById(R.id.buttontext6);

	   TextView    Title7 = (TextView) v.findViewById(R.id.TitleTextView7);
	   TextView    ButtonText7 = (TextView) v.findViewById(R.id.buttontext7);
	   
	   TextView    Title8 = (TextView) v.findViewById(R.id.TitleTextView8);
	   TextView    ButtonText8 = (TextView) v.findViewById(R.id.buttontext8);
 
      
      RulesTextw.setTypeface(TitleFont);
      RulesTextx.setTypeface(TitleFont);
      RulesTexty.setTypeface(TitleFont);
      RulesTextz.setTypeface(TitleFont);
      
      RulesText2w.setTypeface(TitleFont);
      RulesText2x.setTypeface(TitleFont);
      RulesText2y.setTypeface(TitleFont);
      
      RulesText3w.setTypeface(TitleFont);
      RulesText3x.setTypeface(TitleFont);
      RulesText3y.setTypeface(TitleFont);

      RulesText4w.setTypeface(TitleFont);
      RulesText4x.setTypeface(TitleFont);
      RulesText4y.setTypeface(TitleFont);
      RulesText4z.setTypeface(TitleFont);

      RulesText5w.setTypeface(TitleFont);
      RulesText5x.setTypeface(TitleFont);
      RulesText5y.setTypeface(TitleFont);
      RulesText5z.setTypeface(TitleFont);

      RulesText6w.setTypeface(TitleFont);
      RulesText6x.setTypeface(TitleFont);
      RulesText6y.setTypeface(TitleFont);
      RulesText6z.setTypeface(TitleFont);

      RulesText7w.setTypeface(TitleFont);
      RulesText7x.setTypeface(TitleFont);
      RulesText7y.setTypeface(TitleFont);
      RulesText7z.setTypeface(TitleFont);

      RulesText8.setTypeface(NetworkFont);
      

      Title.setTypeface(NetworkFont);
      ButtonText.setTypeface(TitleFont);
     
      Title2.setTypeface(NetworkFont);
      ButtonText2.setTypeface(TitleFont);
      
      Title3.setTypeface(NetworkFont);
      ButtonText3.setTypeface(TitleFont);

      Title4.setTypeface(NetworkFont);
      ButtonText4.setTypeface(TitleFont);
      
      Title5.setTypeface(NetworkFont);
      ButtonText5.setTypeface(TitleFont);

      Title6.setTypeface(NetworkFont);
      ButtonText6.setTypeface(TitleFont);

      Title7.setTypeface(NetworkFont);
      ButtonText7.setTypeface(TitleFont);
      

      Title8.setTypeface(NetworkFont);
      ButtonText8.setTypeface(TitleFont);
      
          	   
   }
  
   

   
}
