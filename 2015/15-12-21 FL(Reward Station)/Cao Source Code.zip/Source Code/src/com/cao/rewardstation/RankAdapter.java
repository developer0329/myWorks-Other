package com.cao.rewardstation;

import java.lang.reflect.Field;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class RankAdapter extends RecyclerView.Adapter<RankAdapter.ViewHolder>  {
	 
    private static final int TYPE_HEADER = 0;  // Declaring Variable to Understand which View is being worked on
                                               // IF the viaew under inflation and population is header or Item
    private static final int TYPE_ITEM = 1;
    static User UserProfile;
    private String dataSource[]; // String Array to store the passed titles Value from MainActivity.java
    Context context; 
	 MainActivity Activity;
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {    
    	int Holderid;
    	protected TextView Username;
        protected TextView Credits;
        protected TextView Refs;
        protected ImageView pic;
        Context contxt;
        MainActivity mActivity;
 
        public ViewHolder(View itemView,int ViewType,Context c,MainActivity Activ) {                 // Creating ViewHolder Constructor with View and viewType As a parameter
            super(itemView);
             contxt = c;
             mActivity = Activ;
            itemView.setClickable(true);
            itemView.setOnClickListener(this);
            // Here we set the appropriate view in accordance with the the view type as passed when the holder object is created
 
            UserProfile = ((MainActivity)mActivity).getUserProfile();
            if(ViewType == TYPE_ITEM) {
                
                Username =  (TextView) itemView.findViewById(R.id.Username);
                pic = (ImageView) itemView.findViewById(R.id.country);
                Credits =  (TextView) itemView.findViewById(R.id.Credits);
              // Refs =  (TextView) itemView.findViewById(R.id.Refs);// setting holder id as 1 as the object being populated are of type item row
                Holderid = 1;    
            }
            else{                                              // Setting holder id = 0 as the object being populated are of type header view

    	       // viewFlipper = (ViewFlipper) itemView.findViewById(R.id.viewflipper);
    	       
    	        Holderid = 0;    
            }
 
 
 
        }
 
 
        @Override
        public void onClick(View v) {
        }
    }
 
 
 
    RankAdapter(String Titles[],Context passedContext,MainActivity Activ){ // DrawerAdapter Constructor with titles and icons parameter
                                            // titles, icons, name, email, profile pic are passed from the main activity as we
    	dataSource = Titles;       
        Activity = Activ;                //here we assign those passed values to the values we declared here
        this.context = passedContext;
 
        //in adapter
 
 
 
    }
 
 
    @Override
    public RankAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
 
        if (viewType == TYPE_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rank_row,parent,false); //Inflating the layout
 
            ViewHolder vhItem = new ViewHolder(v,viewType,context,Activity); //Creating ViewHolder and passing the object of type view
 
            return vhItem; // Returning the created object
 
            //inflate your layout and pass it to view holder
 
        } else if (viewType == TYPE_HEADER) {
 
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rank_header,parent,false); //Inflating the layout
 
            ViewHolder vhHeader = new ViewHolder(v,viewType,context,Activity); //Creating ViewHolder and passing the object of type view
 
            return vhHeader; //returning the object created
 
 
        }
        return null;
 
    }
 
    //Next we override a method which is called when the item in a row is needed to be displayed, here the int position
    // Tells us item at which position is being constructed to be displayed and the holder id of the holder object tell us
    // which view type is being created 1 for item row
    @Override
    public void onBindViewHolder(RankAdapter.ViewHolder holder, int position) {
        if(holder.Holderid ==1) {
        	String OfferFull = dataSource[position];
            String username= null,country= null,credits= null,refs = null;
        	Log.e("Full",OfferFull+"----"+String.valueOf(position));
        	try { 
       	  username = YParser(OfferFull,"name").replace("^", "");
		  country = YParser(OfferFull,"country");
		  credits = YParser(OfferFull,"credits");
		  refs = YParser(OfferFull,"refs");
		Log.e("UsernameXX",username);
        	} catch (Throwable t) {
        	    Log.e("My App", "Could not parse malformed JSON");
        	}
        	
        	try {
//            Picasso.with(context)
//            .load(creative)
//            .placeholder(R.drawable.ic_launcher)
//            .transform(new RoundedTransformation(10, 4))
//            .into(holder.pic);
        		 Typeface ItemFont = Typeface.createFromAsset(context.getAssets(),"BebasNeue Regular.otf"); 
        			holder.Username.setTypeface(ItemFont);
            
        	if (username.equalsIgnoreCase(UserProfile.getname())){
        		holder.Username.setTextColor(context.getResources().getColor(R.color.textbg));	
        	}
            holder.Username.setText(username);
            holder.Credits.setText(credits);
            int resid = getId(country.toLowerCase(), R.drawable.class);
            holder.pic.setImageResource(resid);
        	}
        	catch  (Throwable t) {
        		
        		Log.e("Creative Error",t.getLocalizedMessage());
        	}
        
        }
        else{
//        	String[] items = new String[] { "Chai Latte", "Green Tea", "Black Tea" };
//
//	        holder.viewFlipper.setAutoStart(true);
//	        holder.viewFlipper.setFlipInterval(4000);
//	        holder.viewFlipper.startFlipping();
        }
    }
 
   
    @Override
    public int getItemCount() {
        return dataSource.length; // the number of items in the list will be +1 the titles including the header view.
    }
 
 
    // Witht the following method we check what type of view is being passed
    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
 
        return TYPE_ITEM;
    }
 
    private boolean isPositionHeader(int position) {
        return position == 0;
    }
    
	public static int getId(String resourceName, Class<?> c) {
	    try {
	        Field idField = c.getDeclaredField(resourceName);
	        return idField.getInt(idField);
	    } catch (Exception e) {
	        throw new RuntimeException("No resource ID found for: "
	                + resourceName + " / " + c, e);
	    }
	}
	public String YParser(String in,String fieldname)  {
		String status = null;
		if (in!=null){
		
		JSONObject reader;
		try {
			reader = new JSONObject(in);
			
			//JSONObject response  = reader.getJSONObject("request");
			 status = reader.getString(fieldname);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		}
		else {
			return null;
		}
	}
}