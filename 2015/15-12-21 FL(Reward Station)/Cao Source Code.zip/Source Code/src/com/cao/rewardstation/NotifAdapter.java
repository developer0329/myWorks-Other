package com.cao.rewardstation;

import java.lang.reflect.Field;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class NotifAdapter extends RecyclerView.Adapter<NotifAdapter.ViewHolder>  {
	 
    private static final int TYPE_HEADER = 0;  // Declaring Variable to Understand which View is being worked on
                                               // IF the viaew under inflation and population is header or Item
    private static final int TYPE_ITEM = 1;
    User UserProfile;
    private String dataSource[]; // String Array to store the passed titles Value from MainActivity.java
    Context context; 
    static Context contxt;
	 MainActivity Activity;
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {    
    	protected TextView Message;
        protected ImageView Icon;
        MainActivity mActivity;
 
        public ViewHolder(View itemView,int ViewType,Context c,MainActivity Activ) {                 // Creating ViewHolder Constructor with View and viewType As a parameter
            super(itemView);
             contxt = c;
             mActivity = Activ;
            itemView.setClickable(true);
            itemView.setOnClickListener(this);
  
            Message =  (TextView) itemView.findViewById(R.id.Message);
            Icon = (ImageView) itemView.findViewById(R.id.Icon);
             
 
 
        }
 
 
        @Override
        public void onClick(View v) {
        }
    }
 
 
 
    NotifAdapter(String Titles[],Context passedContext,MainActivity Activ){ // DrawerAdapter Constructor with titles and icons parameter
                                            // titles, icons, name, email, profile pic are passed from the main activity as we
    	dataSource = Titles;       
        Activity = Activ;                //here we assign those passed values to the values we declared here
        this.context = passedContext;
 
        //in adapter
 
 
 
    }
 
 
    @Override
    public NotifAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
 
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.notif_row,parent,false); //Inflating the layout
 
            ViewHolder vhItem = new ViewHolder(v,viewType,context,Activity); //Creating ViewHolder and passing the object of type view
 
            return vhItem; // Returning the created object
 
            //inflate your layout and pass it to view holder
 
 
    }
 
    //Next we override a method which is called when the item in a row is needed to be displayed, here the int position
    // Tells us item at which position is being constructed to be displayed and the holder id of the holder object tell us
    // which view type is being created 1 for item row
    @Override
    public void onBindViewHolder(NotifAdapter.ViewHolder holder, int position) {
     
        	String OfferFull = dataSource[position];
            String Message= null,Icon= null,Url= null, Read=null;
        	Log.e("Full",OfferFull+"----"+String.valueOf(position));
        	try { 
        		Message = YParser(OfferFull,"message");
        		Icon = YParser(OfferFull,"icon");
        		Url = YParser(OfferFull,"link");
        		Read = YParser(OfferFull,"read");
			  Log.e("Notif Message",Message);
        	} catch (Throwable t) {
        	    Log.e("My App", "Could not parse malformed JSON");
        	}
        	
        	 Typeface ItemFont = Typeface.createFromAsset(Activity.getAssets(),"BebasNeue Regular.otf"); 
        	
        	 
        	try {
        		 holder.Message.setTypeface(ItemFont);
            holder.Message.setText(Message);
            int resid1 ; 
            int notiftype = Integer.parseInt(Icon);  
            int readx = Integer.parseInt(Read);
            
            if (notiftype==0){ // New Credits approved
            		if(readx==0){
                    	resid1 = getId("mycredit", R.drawable.class);    
                    	} else {
                    	resid1 = getId("mycreditdark", R.drawable.class);    
                    	}
            }
            else if (notiftype==1){ // New Referral approved
            	if(readx==0){
                	resid1 = getId("myreferral", R.drawable.class);    
                	} else {
                	resid1 = getId("myreferraldark", R.drawable.class);    
                	}
            }
            else if (notiftype==2){ // 
            	if(readx==0){
            	resid1 = getId("mypromo", R.drawable.class);    
            	} else {
            	resid1 = getId("mypromodark", R.drawable.class);    
            	}
            }
            else if (notiftype==3){
            	if(readx==0){
                	resid1 = getId("mydailylogin", R.drawable.class);    
                	} else {
                	resid1 = getId("mydailylogindark", R.drawable.class);    
                	}
            }
            else { 
            	if(readx==0){
                	resid1 = getId("mycredit", R.drawable.class);    
                	} else {
                	resid1 = getId("mycreditdark", R.drawable.class);    
                	}
            }
            
            holder.Icon.setImageResource(resid1);
            
        	
        	}
        	catch  (Throwable t) {
        		
        		Log.e("Creative Error",t.getLocalizedMessage());
        	}
        

     
    }
 
   
    @Override
    public int getItemCount() {
        return dataSource.length; // the number of items in the list will be +1 the titles including the header view.
    }
 
 
 
    
	public static int getId(String resourceName, Class<?> c) {
	    try {
	        Field idField = c.getDeclaredField(resourceName);
	        return idField.getInt(idField);
	    } catch (Exception e) {
	        throw new RuntimeException("No resource ID found for: "
	                + resourceName + " / " + c, e);
	    }
	}
	public String YParser(String in,String fieldname)  {
		String status = null;
		if (in!=null){
		
		JSONObject reader;
		try {
			reader = new JSONObject(in);
			
			//JSONObject response  = reader.getJSONObject("request");
			 status = reader.getString(fieldname);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		}
		else {
			return null;
		}
	}
}