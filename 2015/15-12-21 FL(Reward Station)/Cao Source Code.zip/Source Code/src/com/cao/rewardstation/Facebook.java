package com.cao.rewardstation;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class Facebook extends Fragment {

	   private WebView wv1;
	    private ProgressDialog progressBar;

	@Override
	 public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
	        View v =inflater.inflate(R.layout.activity_offer_wall,container,false);
	        
	    	String url = "https://m.facebook.com/profile.php?id=1616561225266456";

		      wv1=(WebView) v.findViewById(R.id.webview);

		    //  wv1.setWebViewClient(new MyBrowser()); 
		      wv1.getSettings().setLoadsImagesAutomatically(true);
	          wv1.getSettings().setJavaScriptEnabled(true);
	          wv1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
	         wv1.loadUrl(url);
	          
	          
	          progressBar = ProgressDialog.show(this.getActivity(), "Loading", "Please wait...");

	          
	          wv1.setWebViewClient(new WebViewClient() {
	              public boolean shouldOverrideUrlLoading(WebView view, String url) {
	              //    Log.i(TAG, "Processing webview url click...");
	                  view.loadUrl(url);
	                  return true;
	              }

	              public void onPageFinished(WebView view, String url) {
	              //    Log.i(TAG, "Finished loading URL: " + url);
	                  if (progressBar.isShowing()) {
	                      progressBar.dismiss();
	                  }
	              }

	              public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
	            //      Log.e(TAG, "Error: " + description);
	                  Toast.makeText(getActivity(), "Oh no! " + description, Toast.LENGTH_SHORT).show();
	                 
	              }
	          });
	          wv1.loadUrl(url);
	              
			return v;
	      
	        
	}
}
