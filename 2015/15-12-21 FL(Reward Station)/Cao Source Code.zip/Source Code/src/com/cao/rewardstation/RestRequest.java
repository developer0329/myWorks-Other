package com.cao.rewardstation;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Query;

import com.google.gson.JsonElement;

public interface RestRequest {

@POST("/email") //your login function in your api
public void reset(@Query("email") String username,Callback<JsonElement> calback); //this is for your login, and you can used String as response or you can use a POJO, retrofit is very rubust to convert JSON to POJO


@POST("/checkout")
public void Checkout(@Query("cost") String cost,@Query("dollars") String dollars,@Query("id") String userid,@Query("paypal") String paypal,Callback<JsonElement> calback);

@GET("/ranking")
public void GetRank(Callback<JsonElement> calback);

@POST("/profile") //your login function in your api
public void profile(@Query("email") String username,@Query("password") String password,Callback<JsonElement> calback); //this is for your login, and you can used String as response or you can use a POJO, retrofit is very rubust to convert JSON to POJO

@POST("/login") //your login function in your api
public void login(@Query("email") String username,@Query("password") String password,Callback<JsonElement> calback); //this is for your login, and you can used String as response or you can use a POJO, retrofit is very rubust to convert JSON to POJO

@POST("/register") //your login function in your api
public void register(@Query("name") String username, @Query("email") String email, @Query("password") String password, @Query("country") String country,@Query("referral") String referral,@Query("devid") String devid,Callback<JsonElement> calback); //this is for your login, and you can used String as response or you can use a POJO, retrofit is very rubust to convert JSON to POJO




}
