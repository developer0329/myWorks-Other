package com.cao.rewardstation;

import java.lang.reflect.Field;
import java.util.ArrayList;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class Settings extends Fragment implements OnRefreshListener{

	NotifAdapter adapter; 
	 Context mycontxt;
	 private RecyclerView recyclerView;
	 private RecyclerView.LayoutManager layoutManager;
	 MainActivity activity; 
		RestClient MyRestClient;    User UserProfile;
		TextView Name,Email,Credits,Referrals;ImageView Country;
	@Override
	 public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
	        View v =inflater.inflate(R.layout.settings,container,false);
	        final ViewGroup containerx = container;
	         recyclerView = (RecyclerView) v.findViewById(R.id.recycler_view);
		        recyclerView.setHasFixedSize(true);
		        layoutManager = new LinearLayoutManager(this.getActivity());
		        recyclerView.setLayoutManager(layoutManager);
		        

		        TextView   NameLabel = (TextView) v.findViewById(R.id.UsernameLabel);
		        TextView    EmailLabel = (TextView) v.findViewById(R.id.EmailLabel);
		        TextView    CreditsLabel = (TextView) v.findViewById(R.id.CreditsLabel);
		        TextView    ReferralsLabel = (TextView) v.findViewById(R.id.ReferralsLabel);
		        TextView   CountryLabel = (TextView) v.findViewById(R.id.countryLabel);

	        Name = (TextView) v.findViewById(R.id.Username);
	        Email = (TextView) v.findViewById(R.id.Email);
	        Credits = (TextView) v.findViewById(R.id.Credits);
	        Referrals = (TextView) v.findViewById(R.id.Referrals);
	        Country = (ImageView) v.findViewById(R.id.country);
	        
	        Typeface ItemFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Regular.otf"); 
	    	
		 	   Typeface  PageFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Bold.otf"); 
			   TextView   PageTitle = (TextView) v.findViewById(R.id.PageTextView);
			   TextView   PageTitle2 = (TextView) v.findViewById(R.id.PageTextView2);

			   PageTitle.setTypeface(PageFont);
			   PageTitle2.setTypeface(PageFont);
			   

		        NameLabel.setTypeface(PageFont);
		        EmailLabel.setTypeface(PageFont);
		        CreditsLabel.setTypeface(PageFont);
		        ReferralsLabel.setTypeface(PageFont);
		        CountryLabel.setTypeface(PageFont);
		        
		        Name.setTypeface(ItemFont);
		        Email.setTypeface(ItemFont);
		        Credits.setTypeface(ItemFont);
		        Referrals.setTypeface(ItemFont);
		        
	        MyRestClient = ((MainActivity)this.getActivity()).getClient();
	        UserProfile = ((MainActivity)this.getActivity()).getUserProfile();
	        
	      	SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this.getActivity());
	    	 String Email = preferences.getString("Email", "");
	     	 String Password = preferences.getString("Password", "");
	     	if( (Email!="") && (Password!="")){
		     	Login(Email,Password);
	     	} else {
	     		Log.e("Login Error", "No Email & Password available");
	     	}
	     	Button LogoutButton = (Button) v.findViewById(R.id.LogoutButton);
	     	LogoutButton.setOnClickListener(new OnClickListener() {
				 @Override
					public void onClick(View view) {
					 savePreferences("Email","");
            		 savePreferences("Password","");
            		 Intent intent = new Intent(getActivity(), 
            				 SplashActivity.class);
            			 startActivity(intent);
            			 getActivity().finish();
				 	}
					});
	     	LogoutButton.setTypeface(ItemFont);
	     	
//	     	Button ContactButton = (Button) v.findViewById(R.id.ContactButton);
//	     	ContactButton.setOnClickListener(new OnClickListener() {
//				 @Override
//					public void onClick(View view) {
//					 Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
//					            "mailto",getString(R.string.CasheeEmail), null));
//					startActivity(Intent.createChooser(emailIntent, "Send Email"));
//				 	}
//					});

	        return v;    
	}

	
   public static final Settings newInstance(Context context)
   {
   	Settings f = new Settings();
   	f.mycontxt =context;
     Bundle bdl = new Bundle(1);
     f.setArguments(bdl);

     return f;

   }
   
   public void Login(final String email,final String password) {
	 MyRestClient.APICONTROL.profile(email,password,new Callback<JsonElement>() {
	        @Override
	        public void success(JsonElement s, Response response) {
	        	JsonObject jsonObj = s.getAsJsonObject();
	        	String strObj = jsonObj.toString();
	        	//process your response if login successfull you can call Intent and launch your main activity
	        	
	        		 String id =  MyRestClient.XParser(strObj,"id");
	        		 String name =  MyRestClient.XParser(strObj,"name");
	        		 String email =  MyRestClient.XParser(strObj,"email");
	        		 String country =  MyRestClient.XParser(strObj,"country");
	        		 String credits =  MyRestClient.XParser(strObj,"credits");
	        		 String refs =  MyRestClient.XParser(strObj,"refs");
	        		 UserProfile.setcredits(Float.valueOf(credits));
	        		 ((MainActivity)getActivity()).usercredits.setText(String.valueOf(UserProfile.getcredits()));
	        		// String paypal =  MyRestClient.XParser(strObj,"paypal");
	        		 String notifs = MyRestClient.XParser(strObj,"notifications");
	        		 if(notifs.length()>3){

	 		        	ArrayList<String> NotifList = null;
	 		        	NotifList = new ArrayList<String>();
	 		        	
	        			 JsonObject requestobject = jsonObj.getAsJsonObject("request");
	        			 JsonArray NotifArray = requestobject.getAsJsonArray("notifications");
		        		 int len = NotifArray.size();
		        		 for(int i = 0; i < len; ++i) {
		 	        		JsonObject objd = NotifArray.get(i).getAsJsonObject();
		 	        		
		 	        		 String notificon = MyRestClient.YParser(objd.toString(),"icon").replace("^", "");
		 	        		 String notifmessage = MyRestClient.YParser(objd.toString(),"message");
		 	        		String notifurl = MyRestClient.YParser(objd.toString(),"link");
		 	        		String notifread = MyRestClient.YParser(objd.toString(),"read");

		 	        		NotifList.add(objd.toString());
		 	        		}
		        			if (NotifList.isEmpty()){
		    	        		Log.e("Notif List Empty","No notifications at the moment");
		    	        		}
		    	        		else {
		    	        			String[] RankListx = new String[NotifList.size()];
		    	        			RankListx = NotifList.toArray(RankListx);
		    		                adapter = new NotifAdapter(RankListx,mycontxt,
		    		              		  ((MainActivity)getActivity()));
		    		                recyclerView.setAdapter(adapter);
		    		            }
	        		 }	
	        		 Name.setText(name);
	        		 Email.setText(email);
	        		 Credits.setText(credits);
	        		 Referrals.setText(refs);

	                 int resid = getId(country.toLowerCase(), R.drawable.class);
	        		 Country.setImageResource(resid);

	        }
	        @Override
	        public void failure(RetrofitError retrofitError) {
	            retrofitError.printStackTrace(); //to see if you have errors
		        String StatusCode = null;String Message = null; 
	            try {
		            	String GetResponse = new String(((TypedByteArray) retrofitError.getResponse().getBody()).getBytes());
		            	 StatusCode = MyRestClient.StatusParser(GetResponse);
		            	 Message= MyRestClient.MessageParser(GetResponse);

	            		 Log.e("Login Status","Fail");
		            	 
		            }
		            catch (Exception e) {// NOT JSON, CANT PARSE IT.

		            	Log.e("Response Error","Bad Json");
		            }	
	            	
	            	if ( (StatusCode!=null) && (Message!=null)) {
//	            	ShowError(StatusCode,Message);
//	            	 ShowForm(true);
        		}else { // NOT JSON, CANT PARSE IT.
//         			ShowError("XXX",getString(R.string.BadJsonResponse));
//         			 ShowForm(true);
         		}
					
				}
	 		});  
	        
   		}
   
	public static int getId(String resourceName, Class<?> c) {
	    try {
	        Field idField = c.getDeclaredField(resourceName);
	        return idField.getInt(idField);
	    } catch (Exception e) {
	        throw new RuntimeException("No resource ID found for: "
	                + resourceName + " / " + c, e);
	    }
	}


	@Override
	public void onRefresh() {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this.getActivity());
   	 String Email = preferences.getString("Email", "");
    	 String Password = preferences.getString("Password", "");
    	if( (Email!="") && (Password!="")){
	     	Login(Email,Password);
    	} else {
    		Log.e("Login Error", "No Email & Password available");
    	}
		
	}

    private void savePreferences(String key, String value) {
	    SharedPreferences sharedPreferences = PreferenceManager
            .getDefaultSharedPreferences(this.getActivity());
  Editor editor = sharedPreferences.edit();
	    editor.putString(key, value);
	     editor.commit();
	
	    }
}
