package com.cao.rewardstation;

import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.github.johnpersano.supertoasts.SuperCardToast;
import com.github.johnpersano.supertoasts.SuperToast;

public class AdscendActivity extends Activity {

	 private RecyclerView recyclerView;
	 private RecyclerView.LayoutManager layoutManager;
	 SuperCardToast ProgressToast;
	 String pubid,apikey,userip,userid,completed,extraparams;
	 String OffersUrl;
	 OfferAdapter adapter; 
	 AdscendActivity MyActivity;
	 User UserProfile;
	 Context mycontxt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_adscend);
		
		Intent intent = getIntent();
		UserProfile = (User) intent.getSerializableExtra("UserProfile");
		ProgressToast = new SuperCardToast(this, SuperToast.Type.PROGRESS);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mycontxt=getApplicationContext();
        MyActivity=this;
        pubid= getString(R.string.pubid);
        apikey= getString(R.string.apikey);
        userip= UserProfile.getip();
        userid= String.valueOf(UserProfile.getid());
        //extraparams ="&simulate_country=US";
       String useragent ="&useragent=Mozilla%2F5.0%20(Linux%3B%20Android%204.0.4%3B%20Galaxy%20Nexus%20Build%2FIMM76B)%20AppleWebKit%2F535.19%20(KHTML%2C%20like%20Gecko)%20Chrome%2F18.0.1025.133%20Mobile%20Safari%2F535.19";

    	OffersUrl = "http://adscendmedia.com/api-get.php?pubid="+pubid+"&key="+apikey+"&mode=offers&user_ip="+userip+"&user_subid="+userid+"&include_completed=0&date_range=0&sort=epc&adlock_mode=1&free_offers=1&cell_offers=1&trial_offers=1&only_instant=1&creative=1"+useragent;
    	Log.e("url", OffersUrl);
       ShowProgress(getString(R.string.OfferString));
       new GetOffers().execute();
    	 
	}

    private class GetOffers extends AsyncTask<String, String, JSONObject> {
       @Override
       protected void onPreExecute() {
           super.onPreExecute();
       }
      
       @Override
       protected JSONObject doInBackground(String... args) {
           URLShortener jParser = new URLShortener();
         JSONObject json = jParser.getJSONFromUrl(OffersUrl,"");
          
           return json;
       }
        @Override
        protected void onPostExecute(JSONObject json) {

        	ArrayList<String> myOfferList = null;
        	myOfferList = new ArrayList<String>();
        	myOfferList.add("Referral Offer");
        	myOfferList.add("Referral Offer");
        	if (ProgressToast.isShowing()){
        	ProgressToast.dismiss();
        	}
        	
          if (json != null){
               for(Iterator<String> iter = json.keys();iter.hasNext();) {
            	   String key = iter.next();
            	   try {
            		   JSONObject value = json.getJSONObject(key);
            		   if(!value.toString().isEmpty()){
            			   	try{
              				Log.e("VALUE",value.toString());
            			    } catch (Exception e) {
                    	        // Something went wrong!
                    	    	Log.e("Value","something went wrong");
                    	    }
                        		
            		   myOfferList.add(value.toString());
            		   
            		   }
            	    } catch (JSONException e) {
            	        // Something went wrong!
            	    	Log.e("Value","something went wrong");
            	    }
                		    
                }

           }
         
          if (myOfferList.size()<3){
        	  
        	  ShowError("No Offers available, please try again later");
        	  
          }else {
	          String[] MyOfferData = new String[myOfferList.size()];
	          Log.e("ResultYY",MyOfferData.toString());
	          MyOfferData = myOfferList.toArray(MyOfferData);
	          adapter = new OfferAdapter(
	        		  MyOfferData,
	        		  mycontxt,MyActivity);
	          recyclerView.setAdapter(adapter);
          }

        }
   }
    
    public void ShowProgress(String msgId){
    	ProgressToast = new SuperCardToast(this, SuperToast.Type.PROGRESS);
      	ProgressToast.setText(msgId);
     	ProgressToast.setBackground(SuperToast.Background.BLUE);
     	ProgressToast.setTextColor(Color.WHITE);
     	//ProgressToast.setDuration(SuperToast.Duration.LONG);
     	ProgressToast.setIndeterminate(true);
     	ProgressToast.setProgressIndeterminate(true);
     	ProgressToast.setSwipeToDismiss(true);
     	ProgressToast.setTouchToDismiss(true);
     	ProgressToast.show();
          
    }
  
 public void ShowError(String Message){

	   // Toast.makeText(this.getActivity()(), ErrorPhrase, Toast.LENGTH_LONG).show();
	   SuperCardToast superCardToast = new SuperCardToast(this);
	  superCardToast.setText(Message);
	  superCardToast.setDuration(SuperToast.Duration.EXTRA_LONG);
	  superCardToast.setBackground(SuperToast.Background.RED);
	  superCardToast.setTextColor(Color.WHITE);
	  superCardToast.setSwipeToDismiss(true);
   		superCardToast.setTouchToDismiss(true);
	  superCardToast.show();
   }
 
public void ShowGood(String msgId){
	final SuperCardToast superCardToast = new SuperCardToast(this, SuperToast.Type.STANDARD);
  	superCardToast.setText(msgId);
 	superCardToast.setBackground(SuperToast.Background.GREEN);
 	superCardToast.setIcon(SuperToast.Icon.Dark.INFO, SuperToast.IconPosition.LEFT);
 	superCardToast.setTextColor(Color.WHITE);
 	superCardToast.setDuration(SuperToast.Duration.LONG);
 	superCardToast.setTouchToDismiss(true);
 	superCardToast.show();
}
}
