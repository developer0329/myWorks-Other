package com.cao.rewardstation;

public interface Constants {
	

	   public String BASE_URL = "http://phplaravel-13598-29616-74909.cloudwaysapps.com//";
	   
}
