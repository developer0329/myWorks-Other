package com.cao.rewardstation;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Faq  extends Fragment {


	@Override
	 public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
	        View v =inflater.inflate(R.layout.faq,container,false);

	  Typeface ItemFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Regular.otf"); 
	  Typeface  PageFont = Typeface.createFromAsset(this.getActivity().getAssets(),"BebasNeue Bold.otf"); 
	  
	  TextView   PageTitle = (TextView) v.findViewById(R.id.PageTextView);
	  PageTitle.setTypeface(PageFont);

	  TextView   Title1 = (TextView) v.findViewById(R.id.Title1);
	  TextView   Text1 = (TextView) v.findViewById(R.id.Text1);
	  TextView   Title2 = (TextView) v.findViewById(R.id.Title2);
	  TextView   Text2 = (TextView) v.findViewById(R.id.Text2);
	  TextView   Title3 = (TextView) v.findViewById(R.id.Title3);
	  TextView   Text3 = (TextView) v.findViewById(R.id.Text3);
	  TextView   Title4 = (TextView) v.findViewById(R.id.Title4);
	  TextView   Text4 = (TextView) v.findViewById(R.id.Text4);
	  TextView   Title5 = (TextView) v.findViewById(R.id.Title5);
	  TextView   Text5 = (TextView) v.findViewById(R.id.Text5);
	  TextView   FBShare = (TextView) v.findViewById(R.id.Referralbutton);

	  Title1.setTypeface(PageFont);
	  Text1.setTypeface(ItemFont);
	  Title2.setTypeface(PageFont);
	  Text2.setTypeface(ItemFont);
	  Title3.setTypeface(PageFont);
	  Text3.setTypeface(ItemFont);
	  Title4.setTypeface(PageFont);
	  Text4.setTypeface(ItemFont);
	  Title5.setTypeface(PageFont);
	  Text5.setTypeface(ItemFont);
	  FBShare.setTypeface(PageFont);
	  

		// Facebook Referral
 		CardView Referrals = (CardView) v.findViewById(R.id.Referrals);
 		Referrals.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
      	Intent share = new Intent(android.content.Intent.ACTION_SEND);
			 share.setType("text/plain");
				share.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id="+getActivity().getApplicationContext().getPackageName());

				getActivity().startActivity(Intent.createChooser(share, "Share your Invitation link"));
			
      }
      });
 		
			return v;
	      
	        
	}
}
