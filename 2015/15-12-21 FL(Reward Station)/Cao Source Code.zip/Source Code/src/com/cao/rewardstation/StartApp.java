package com.cao.rewardstation;

import android.app.Application;

import com.parse.Parse;
import com.parse.ParseACL;
import com.parse.ParseUser;


public class StartApp extends Application {

  @Override
  public void onCreate() {
    super.onCreate();

    Parse.initialize(this,"kFT8sdwJhp27Zg9WeFywdXHEfpLxfQrwSD83MFvE", "kPUbjvIkyt7BDXXUYJlzWW2tZ0jYUffTAkIB8sMy");
   
    ParseUser.enableAutomaticUser();
    ParseACL defaultACL = new ParseACL();
    // Optionally enable public read access.
    // defaultACL.setPublicReadAccess(true);
    ParseACL.setDefaultACL(defaultACL, true);
  }
}
