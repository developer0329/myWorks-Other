$(document).ready(function() {
  var viewModel = function() {
    self = this;

    self.percentage = ko.observable(0);

    self.percentage.subscribe(function () {
      if (self.percentage() === 100) {
        clearTimeout(timer);
      }
    });
  };

  ko.bindingHandlers.progressBar = {
    init: function(element) {
      return { controlsDescendantBindings: true };
    },
    update : function(element, valueAccessor, bindingContext) {
      var options = ko.unwrap(valueAccessor());
      var value = options.value();

      //  Stop progress bar value
      if(value > 60) return;

      var width = value + "%";      
      $(element).addClass("progressBar");

      ko.applyBindingsToNode(element, {
        html : '<div data-bind="style: { width: \'' + width + '\' }"></div><div class="progressText" data-bind="text: \'' + value + ' %\'"></div>'
      });

      ko.applyBindingsToDescendants(bindingContext, element);
    }
  };

  var viewModelObj = new viewModel();

  ko.applyBindings(viewModelObj);

  var timer = setInterval(function() { viewModelObj.percentage(viewModelObj.percentage() + 1); }, 50);
});