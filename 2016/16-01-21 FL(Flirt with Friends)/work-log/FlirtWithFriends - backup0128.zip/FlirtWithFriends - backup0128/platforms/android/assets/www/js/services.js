angular.module('starter.services', [])

.factory('Api', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var datas = [{
    id: 0,
    galleryId:'jssor_0',
    name: 'Ben Sparrow',
    gender:'Male',
    lastText: 'You on your way?',
    face: 'img/ben.png'
  }, {
    id: 1,
    galleryId:'jssor_1',
    name: 'Max Lynx',
    gender:'Male',
    lastText: 'Hey, it\'s me',
    face: 'img/max.png'
  }, {
    id: 2,
    galleryId:'jssor_2',
    name: 'Adam Bradleyson',
    gender:'Male',
    lastText: 'I should buy a boat',
    face: 'img/adam.jpg'
  }, {
    id: 3,
    galleryId:'jssor_3',
    name: 'Perry Governor',
    lastText: 'Look at my mukluks!',
    gender:'Female',
    face: 'img/perry.png'
  }, {
    id: 4,
    galleryId:'jssor_4',
    name: 'Mike Harrington',
    gender:'Female',
    lastText: 'This is wicked good ice cream.',
    face: 'img/mike.png'
  },
  {
     id: 5,
     galleryId:'jssor_6',
     name: 'Maxy Lynx',
     gender:'Male',
     lastText: 'Hey, it\'s me',
     face: 'img/max.png'
  }, {
     id: 6,
     galleryId:'jssor_6',
     name: 'Adamy Bradleyson',
     gender:'Male',
     lastText: 'I should buy a boat',
     face: 'img/adam.jpg'
  }, {
     id: 7,
     galleryId:'jssor_7',
     name: 'Perryx Governor',
     lastText: 'Look at my mukluks!',
     gender:'Female',
     face: 'img/perry.png'
  }, {
     id: 8,
     galleryId:'jssor_8',
     name: 'Mikey Harrington',
     gender:'Female',
     lastText: 'This is wicked good ice cream.',
     face: 'img/mike.png'
  },
  {
     id: 9,
     galleryId:'jssor_9',
     name: 'Mikey Harry',
     gender:'Female',
     lastText: 'This is wicked good ice cream.',
     face: 'img/mike.png'
  }];

  return {
    all: function() {
      return datas;
    },
    remove:function(datas, value){
        var index = datas.indexOf(value);
        datas.splice(index, 1);
      return datas;
    },
    get: function(dataId) {
      for (var i = 0; i < datas.length; i++) {
        if (datas[i].id === parseInt(dataId)) {
          return datas[i];
        }
      }
      return null;
    }
  };
})
.factory('MockService', ['$http', '$q',
  function($http, $q) {
    var me = {};

    me.getUserMessages = function(d) {
      /*
      var endpoint =
        'http://www.mocky.io/v2/547cf341501c337f0c9a63fd?callback=JSON_CALLBACK';
      return $http.jsonp(endpoint).then(function(response) {
        return response.data;
      }, function(err) {
        console.log('get user messages error, err: ' + JSON.stringify(
          err, null, 2));
      });
      */
      var deferred = $q.defer();

		 setTimeout(function() {
      	deferred.resolve(getMockMessages());
	    }, 1500);

      return deferred.promise;
    };

    me.getMockMessage = function() {
      return {
        userId: '534b8e5aaa5e7afc1b23e69b',
        date: new Date(),
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'
      };
    }

    return me;
  }
])


function getMockMessages() {
  return {"messages":[{"_id":"535d625f898df4e80e2a125e","text":"Ionic has changed the game for hybrid app development.","userId":"534b8fb2aa5e7afc1b23e69c","date":"2014-04-27T20:02:39.082Z","read":true,"readDate":"2014-12-01T06:27:37.944Z"},{"_id":"535f13ffee3b2a68112b9fc0","text":"I like Ionic better than ice cream!","userId":"534b8e5aaa5e7afc1b23e69b","date":"2014-04-29T02:52:47.706Z","read":true,"readDate":"2014-12-01T06:27:37.944Z"},{"_id":"546a5843fd4c5d581efa263a","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.","userId":"534b8fb2aa5e7afc1b23e69c","date":"2014-11-17T20:19:15.289Z","read":true,"readDate":"2014-12-01T06:27:38.328Z"},{"_id":"54764399ab43d1d4113abfd1","text":"Am I dreaming?","userId":"534b8e5aaa5e7afc1b23e69b","date":"2014-11-26T21:18:17.591Z","read":true,"readDate":"2014-12-01T06:27:38.337Z"},{"_id":"547643aeab43d1d4113abfd2","text":"Is this magic?","userId":"534b8fb2aa5e7afc1b23e69c","date":"2014-11-26T21:18:38.549Z","read":true,"readDate":"2014-12-01T06:27:38.338Z"},{"_id":"547815dbab43d1d4113abfef","text":"Gee wiz, this is something special.","userId":"534b8e5aaa5e7afc1b23e69b","date":"2014-11-28T06:27:40.001Z","read":true,"readDate":"2014-12-01T06:27:38.338Z"},{"_id":"54781c69ab43d1d4113abff0","text":"I think I like Ionic more than I like ice cream!","userId":"534b8fb2aa5e7afc1b23e69c","date":"2014-11-28T06:55:37.350Z","read":true,"readDate":"2014-12-01T06:27:38.338Z"},{"_id":"54781ca4ab43d1d4113abff1","text":"Yea, it's pretty sweet","userId":"534b8e5aaa5e7afc1b23e69b","date":"2014-11-28T06:56:36.472Z","read":true,"readDate":"2014-12-01T06:27:38.338Z"},{"_id":"5478df86ab43d1d4113abff4","text":"Wow, this is really something huh?","userId":"534b8fb2aa5e7afc1b23e69c","date":"2014-11-28T20:48:06.572Z","read":true,"readDate":"2014-12-01T06:27:38.339Z"},{"_id":"54781ca4ab43d1d4113abff1","text":"Create amazing apps - ionicframework.com","userId":"534b8e5aaa5e7afc1b23e69b","date":"2014-11-29T06:56:36.472Z","read":true,"readDate":"2014-12-01T06:27:38.338Z"}],"unread":0};
}