angular.module('starter', ['ionic', 'starter.controllers', 'starter.services', 'starter.directives', 'starter.filters',
 'monospaced.elastic', 'angularMoment'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    console.log("-----------------running function------------");
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})
.config
(
    [
        '$stateProvider',
        '$urlRouterProvider',
        '$ionicConfigProvider',
        function($stateProvider, $urlRouterProvider,  $ionicConfigProvider)
        {
            $ionicConfigProvider.tabs.position('top');

            $stateProvider
                .state('login', {
                    url : '/login',
                    templateUrl : 'templates/login.html',
                    controller : 'LoginController'
                })

                .state('main', {
                    url : '/main',
                    templateUrl : 'templates/main.html',
                    abstract : true,
                    controller : 'MainController'
                })
                .state('main.friends', {
                    url: '/main/friends',
                    views: {
                        'main-friends': {
                            templateUrl: 'templates/friends.html',
                            controller : 'FriendsController'
                        }
                    }
                })
                .state('main.chats', {
                    url: '/main/chats',
                    views: {
                        'main-chats': {
                            templateUrl: 'templates/message-list.html',
                            controller : 'MsgListController'
                        }
                    }
                })
                .state('main.user', {
                    url: '/main/user',
                    views: {
                        'main-user': {
                            templateUrl: 'templates/user-setting.html',
                            controller : 'UserSettingController'
                        }
                    }
                })

                .state('sub', {
                    url : '/sub',
                    templateUrl : 'templates/sub-abstract.html',
                    abstract : true,
                    controller : 'SubController'
                })
                .state('sub.home', {
                    url: '/sub/home',
                    views: {
                        'sub': {
                            templateUrl: 'templates/sub-home.html',
                            controller : 'SubHomePageController'
                        }
                    }
                })
                .state('sub.detail', {
                    url: 'sub/detail/:id',
                    views: {
                        'sub': {
                            templateUrl: 'templates/friend-detail.html',
                            controller : 'FriendDetailController'
                        }
                    }
                })
                .state('sub.msg', {
                    url: '/chatting/:id',
                    views: {
                        'sub': {
                            templateUrl: 'templates/message-send.html',
                            controller : 'UserMessagesCtrl'
                        }
                    }
                })
                .state('sub.rate', {
                    url: '/rate/:id',
                    views: {
                        'sub': {
                            templateUrl: 'templates/sub-rate.html',
                            controller : 'SubRatePageController'
                        }
                    }
                })


            $urlRouterProvider.otherwise('/login');

        }
    ]
);
