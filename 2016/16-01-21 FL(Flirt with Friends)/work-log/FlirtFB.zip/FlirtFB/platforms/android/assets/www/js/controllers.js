var UserInfo={
    id:0,
    face:""
};
var datas=[];

var get= function(dataId) {
  for (var i = 0; i < datas.length; i++) {
    if (datas[i].id === parseInt(dataId)) {
      return datas[i];
    }
  }
  return null;
}


angular.module('starter.controllers', [])

.controller('LoginController', function($scope, $ionicSideMenuDelegate,$state) {
    function sortMethod(a, b) {
       var x = a.name.toLowerCase();
       var y = b.name.toLowerCase();
       return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    }
    var GetFriends=function(count){
       facebookConnectPlugin.api('/me/taggable_friends?pretty=0&limit='+String(count), ["user_friends"],
         function (response) {
           var friend_data = response.data.sort(sortMethod);
           if(friend_data.length > 0 ){
               var id=0;
               for (var i = 0; i < friend_data.length; i++) {
                  var dt={
                    face:friend_data[i].picture.data.url,
                    name:friend_data[i].name,
                    id:id
                  };
                  datas.push(dt);
                  id=id+1;
               }
               // and display them at our holder element

               // console.log("id_length="+JSON.stringify(datas));
                $state.go("main.friends");

           }
         },
         function (response) { alert(JSON.stringify(response)) }
       );
    }


    var apiTestGetFriends= function () {
      facebookConnectPlugin.api('/me/friends', ["user_friends"],
           function (response) {
             GetFriends(response.summary.total_count);
           },
           function (response) { alert(JSON.stringify(response));}
      );

    };

    $scope.login=function(){
        if (!window.cordova) {
            var appId = prompt("Enter FB Application ID", "");
            facebookConnectPlugin.browserInit(appId);
        }
        facebookConnectPlugin.login( ["email"],
            function (response) {
                  UserInfo.id=response.authResponse.userID;
                  UserInfo.face="http://graph.facebook.com/" + response.authResponse.userID + "/picture?type=square";
                  if(UserInfo.id==0) $state.go("login");
                  apiTestGetFriends();

            },
            function (response) { alert(JSON.stringify(response)) }
         );
    }

    $scope.logout=function(){
        facebookConnectPlugin.logout(
            function (response) { alert(JSON.stringify(response));},
            function (response) { alert(JSON.stringify(response)); }
        );
    }

})

.controller('MainController', function($scope, $ionicSideMenuDelegate) {

})
.controller('FriendsController', function($scope, $ionicSideMenuDelegate, Api) {
//    $scope.friends = Api.all();
    $scope.friends = datas;
})

.controller('SubController', function($scope, $ionicSideMenuDelegate) {
})

.controller('SubHomePageController', function($scope, $ionicSideMenuDelegate) {
})

.controller('UserMessagesCtrl',
    ['$scope', '$rootScope', '$state', '$stateParams', 'MockService', '$ionicActionSheet',
    '$ionicPopup', '$ionicScrollDelegate', '$timeout', '$interval', '$ionicHistory', 'Api',
    function($scope, $rootScope, $state, $stateParams, MockService, $ionicActionSheet,
            $ionicPopup, $ionicScrollDelegate, $timeout, $interval, $ionicHistory, Api)
    {

//
    }
])
.controller('FriendDetailController', function($scope, $ionicSideMenuDelegate, $stateParams, $ionicHistory) {

    $scope.friend = get($stateParams.id);
    $scope.show_list = "profile";
//    var galleryId = $scope.friend.galleryId;
    var galleryId = $scope.friend.id;
    $scope.ratingsObject = {
            iconOn: 'ion-ios-star',
            iconOff: 'ion-ios-star-outline',
            iconOnColor: 'rgb(200, 200, 100)',
            iconOffColor: 'rgb(200, 100, 100)',
            rating: 3,
            minRating: 0,
            readOnly:true
        };

    $scope.$on("$ionicView.enter", function() {
        console.log("OK: " + galleryId);
        jssor_1_slider_init(galleryId);
    });
})

.controller('SubNavController', function($scope, $ionicSideMenuDelegate) {
  $scope.toggleLeft = function() {
    $ionicSideMenuDelegate.toggleLeft();
  };
})

.controller('SubRatePageController', function($scope, $ionicSideMenuDelegate, $stateParams, $ionicHistory) {

//      $scope.friend = Api.get($stateParams.id);
      $scope.friend = get($stateParams.id);

      var cur_rating = 0;
      var ini_rating = 0;

      $scope.ratingsObject = {
        iconOn: 'ion-ios-star',
        iconOff: 'ion-ios-star-outline',
        iconOnColor: 'rgb(200, 200, 100)',
        iconOffColor: 'rgb(200, 100, 100)',
        rating: 0,
        minRating: 0,
        readOnly:false,
        callback: function(rating) {
          $scope.ratingsCallback(rating);
        }
      };

      $scope.ratingsCallback = function(rating) {
        cur_rating = rating;
        console.log('Selected rating is : ' + rating);
      };

      $scope.ratingSave = function() {
          console.log('Selected Save Rating is : ' + cur_rating);
          $ionicHistory.goBack();
      };

      $scope.ratingCancel = function() {
          console.log('Selected Cancel Rating is : ' + ini_rating);
          $ionicHistory.goBack();
      };

      $scope.myGoBack = function() {
          $ionicHistory.goBack();
      };
})
