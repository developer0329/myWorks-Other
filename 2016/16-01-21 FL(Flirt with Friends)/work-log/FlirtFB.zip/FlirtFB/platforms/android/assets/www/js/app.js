// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

.config(
    [
        '$stateProvider',
        '$urlRouterProvider',
        '$ionicConfigProvider',
         function($stateProvider, $urlRouterProvider,$ionicConfigProvider) {

              // Ionic uses AngularUI Router which uses the concept of states
              // Learn more here: https://github.com/angular-ui/ui-router
              // Set up the various states which the app can be in.
              // Each state's controller can be found in controllers.js

               $ionicConfigProvider.tabs.position('top');

               $stateProvider
                  .state('login', {
                      url : '/login',
                      templateUrl : 'templates/login.html',
                      controller : 'LoginController'
                  })
                  .state('main', {
                      url : '/main',
                      templateUrl : 'templates/main.html',
                      abstract : true,
                      controller : 'MainController'
                  })
                  .state('main.friends', {
                      url: '/main/friends',
                      views: {
                          'main-friends': {
                              templateUrl: 'templates/friends.html',
                              controller : 'FriendsController'
                          }
                      }
                  })
                  .state('main.chats', {
                      url: '/main/chats',
                      views: {
                          'main-chats': {
                              templateUrl: 'templates/message-list.html',
                              controller : 'MsgListController'
                          }
                      }
                  })
                  .state('main.user', {
                      url: '/main/user',
                      views: {
                          'main-user': {
                              templateUrl: 'templates/user-setting.html',
                              controller : 'UserSettingController'
                          }
                      }
                  })
                  .state('sub', {
                      url : '/sub',
                      templateUrl : 'templates/sub-abstract.html',
                      abstract : true,
                      controller : 'SubController'
                  })
                  .state('sub.home', {
                      url: '/sub/home',
                      views: {
                          'sub': {
                              templateUrl: 'templates/sub-home.html',
                              controller : 'SubHomePageController'
                          }
                      }
                  })
                  .state('sub.detail', {
                    url: 'sub/detail/:id',
                    views: {
                        'sub': {
                            templateUrl: 'templates/friend-detail.html',
                            controller : 'FriendDetailController'
                        }
                    }
                  })
                  .state('sub.msg', {
                      url: '/chatting/:id',
                      views: {
                          'sub': {
                              templateUrl: 'templates/message-send.html',
                              controller : 'UserMessagesCtrl'
                          }
                      }
                  })
                  .state('sub.rate', {
                      url: '/rate/:id',
                      views: {
                          'sub': {
                              templateUrl: 'templates/sub-rate.html',
                              controller : 'SubRatePageController'
                          }
                      }
                  })


              // if none of the above states are matched, use this as the fallback

              $urlRouterProvider.otherwise('/login');
         }


    ]

);
