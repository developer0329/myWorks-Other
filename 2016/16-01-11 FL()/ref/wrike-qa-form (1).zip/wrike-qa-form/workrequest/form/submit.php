<?php

//inlcude files
require_once( dirname(dirname(__FILE__)) . "/config/wrike_config.php" );
require_once( dirname(dirname(__FILE__)) . "/controller/logging.php" );
require_once( dirname(dirname(__FILE__)) . "/controller/wrike_api_authentication.php");
require_once( dirname(dirname(__FILE__)) . "/controller/wrike_api_get_calls.php");
require_once( dirname(dirname(__FILE__)) . "/controller/wrike_api_post_calls.php");

//declar classes
$wrikeAPIAuth = new WrikeAPIAuth();
$wrikeAPIGetCalls = new WrikeAPIGetCalls();
$wrikeAPIPOSTCalls = new WrikeAPIPostCalls();

// get global post variables
$key  = $_POST['key'];
$clientID = $wrikeConfig["clientID"];
$clientSecret = $wrikeConfig["clientSecrete"];
$response = array();
	$logger = new Logger();

// Process Form
switch($_POST['wr_work_type']) {
	// if copyedit was selected
	case 'ce':
		
		//get selected task information in order to get parent folder of task
		$taskCE = $_POST['wr_ce_task'];
		$task =	$wrikeAPIGetCalls->getTaskByID($key,$clientID,$clientSecret,$taskCE);
		$task = json_decode($task,true);

		// declar post variables and make post call to wrike
		$parentIdFromData  =  $task['data'][0]['parentIds'][0];
		//$logger->writeToLog("parentIdFromData: ",$parentIdFromData);
		
		$parentFolderData =	$wrikeAPIGetCalls->getFolderInfo($key,$clientID,$clientSecret,$parentIdFromData);
		$parentFolderData = json_decode($parentFolderData,true);
		$parentFolderDataID = $parentFolderData['data'][0]['parentIds'][0];

		$parentFolderTreeData =	$wrikeAPIGetCalls->getParentIdFolderTree($key,$clientID,$clientSecret,$parentFolderDataID);
		$parentFolderTreeData = json_decode($parentFolderTreeData,true);
		
		foreach($parentFolderTreeData['data'] as $treeData){

			if(strpos($treeData['title'],'3_Multimedia Design and Development') !== false){
				$multiID = $treeData['id'];
			}
		}

		$secoundaryFolderID = "IEAAHSNFI4AZOGS5";
		$title =  $task['data'][0]['title'];
		$projectTaskCE = $wrikeConfig["projectTaskSuffixCE"];
		$titleNew = str_replace("_QA Date Deadline: QA Request Made", "", $title);
		$titleNew  = $titleNew.$projectTaskCE;
		$wrWorkComplete =  $_POST['wr_date_work_complete'];
		$wrCeDesc = $_POST['wr_ce_desc'];
		$wrCELoc = $_POST['wr_ce_loc'];
		$wrCELocInput = $_POST['wr_ce_loc_input'];
		$wrCoidEmail = $_POST['wr_coid_email'];
		$wrLidEmail = $_POST['wr_lid_email'];
		$wrLMSLink = $_POST['wr_lms_link'];
		$wrUserName = $_POST['wr_username'];
		$wrPassword = $_POST['wr_password'];
		$wrCourseLink = $_POST['wr_course_link'];
		$wrCourseLoc = $_POST['wr_course_loc'];
		$wrDataCourseLaunch = $_POST['wr_date_course_launch'];
		if($multiID){
			$parents = "'$secoundaryFolderID','$multiID'";
		}
		else{
			$parents = "'$secoundaryFolderID'";
		}
		
		$postCEResponse = $wrikeAPIPOSTCalls->postCEData($key,$clientID,$clientSecret,$taskCE,$secoundaryFolderID,$parents,$projectTaskCE,
		$wrWorkComplete,$wrCeDesc,$wrCELoc,$wrCELocInput,$wrCoidEmail,$wrLMSLink,$wrUserName,$wrPassword,$wrCourseLink,
		$wrCourseLoc,$wrDataCourseLaunch,$titleNew,$wrLidEmail);
					// return link to record
			$permalink = $postCEResponse['data'][0]['permalink'];
		

		$response = array(
			'title' => "Request Complete: Copy-edit",
			'text' => "Below are links to the new items:",
			'results' => $permalink
		);	
			echo json_encode($response);
		break;
	
	//if transcription
	case 'ts':
		//get selected task information in order to get parent folder of task
		$taskTS = $_POST['wr_ts_task'];
		$task =	$wrikeAPIGetCalls->getTaskByID($key,$clientID,$clientSecret,$taskTS);
		$task = json_decode($task,true);
		
		// declar post variables and make post call to wrike
		//$parentId =  $task['data'][0]['parentIds'][0];
		// declar post variables and make post call to wrike
		$parentIdFromData  =  $task['data'][0]['parentIds'][0];
		$logger->writeToLog("parentIdFromData: ",$parentIdFromData);
		
		$parentFolderData =	$wrikeAPIGetCalls->getFolderInfo($key,$clientID,$clientSecret,$parentIdFromData);
		$parentFolderData = json_decode($parentFolderData,true);
		$parentFolderDataID = $parentFolderData['data'][0]['parentIds'][0];

		$parentFolderTreeData =	$wrikeAPIGetCalls->getParentIdFolderTree($key,$clientID,$clientSecret,$parentFolderDataID);
		$parentFolderTreeData = json_decode($parentFolderTreeData,true);
		
		foreach($parentFolderTreeData['data'] as $treeData){

			if(strpos($treeData['title'],'3_Multimedia Design and Development') !== false){
				$multiID = $treeData['id'];
			}
		}
		
		$parentId = "IEAAHSNFI4AZOGTG";
		$title =  $task['data'][0]['title'];
		$titleNew = str_replace("_QA Date Deadline: QA Request Made", "", $title);
		$projectTaskTS = $wrikeConfig["projectTaskSuffixTS"];
		$titleNew  = $titleNew.$projectTaskTS;
		$wrWorkComplete =  $_POST['wr_date_work_complete'];
		$wrTSDesc = $_POST['wr_ts_desc'];
		$wrTSLoc = $_POST['wr_ts_loc'];
		$wrTSSpecific = $_POST['wr_ts_specific'];
		$wrTSLocInput = $_POST['wr_ts_loc_input'];
		$wrCoidEmail = $_POST['wr_coid_email'];
		$wrLidEmail = $_POST['wr_lid_email'];
		$wrLMSLink = $_POST['wr_lms_link'];
		$wrUserName = $_POST['wr_username'];
		$wrPassword = $_POST['wr_password'];
		$wrCourseLink = $_POST['wr_course_link'];
		$wrCourseLoc = $_POST['wr_course_loc'];
		$wrDataCourseLaunch = $_POST['wr_date_course_launch'];
		
					$logger->writeToLog("multiID: ",$multiID);
					
		if($multiID){
			$parents = "'$parentId','$multiID'";
		}
		else{
			$parents = "'$parentId'";
		}
		
			$logger->writeToLog("parents: ",$parents);
		
		$postTSResponse = $wrikeAPIPOSTCalls->postTSData($key,$clientID,$clientSecret,$taskTS,$parentId,$parents,$projectTaskTS,
		$wrWorkComplete,$wrTSDesc,$wrTSLoc,$wrTSSpecific,$wrTSLocInput,$wrCoidEmail,$wrLMSLink,$wrUserName,$wrPassword,$wrCourseLink,
		$wrCourseLoc,$wrDataCourseLaunch,$titleNew,$wrLidEmail);

		// return link to record
		$permalink = $postTSResponse['data'][0]['permalink'];	
		
		$response = array(
			'title' => "Request Complete: Transcription",
			'text' => "Below are links to the new items:",
			'results' => "$permalink"
		);
			echo json_encode($response);
		break;

	case 'qa':
		//get selected task information in order to get parent folder of task
		$taskQA = $_POST['wr_qa_task'];
		$task =	$wrikeAPIGetCalls->getTaskByID($key,$clientID,$clientSecret,$taskQA);
		$task = json_decode($task,true);
		
		// declar post variables and make post call to wrike
		//$parentId =  $task['data'][0]['parentIds'][0];

		$title =  $task['data'][0]['title'];
		
		$parentIdFromData  =  $task['data'][0]['parentIds'][0];
		//$logger->writeToLog("parentIdFromData: ",$parentIdFromData);
		
		$parentFolderData =	$wrikeAPIGetCalls->getFolderInfo($key,$clientID,$clientSecret,$parentIdFromData);
		$parentFolderData = json_decode($parentFolderData,true);
		$parentFolderDataID = $parentFolderData['data'][0]['parentIds'][0];

		$parentFolderTreeData =	$wrikeAPIGetCalls->getParentIdFolderTree($key,$clientID,$clientSecret,$parentFolderDataID);
		$parentFolderTreeData = json_decode($parentFolderTreeData,true);
		
		foreach($parentFolderTreeData['data'] as $treeData){

			if(strpos($treeData['title'],'4_Course Development Finalization and Quality Assurance') !== false){
				$multiID = $treeData['id'];
			}
		}
		
		
		if( $_POST['wr_qa_type'] == 'Back Only') {
			$parentId = "IEAAHSNFI4A5SOX6";
			if($multiID){
				$parents = "'$parentId','$multiID'";
			}
			else{
				$parents = "'$parentId'";
			}
			$titleNew = str_replace("_QA Date Deadline: QA Request Made", "", $title);
			$titleNew  = $titleNew."_QA Back-End";
			$wrWorkComplete =  $_POST['wr_date_work_complete'];
			$wrCoidEmail = $_POST['wr_coid_email'];
			$wrLidEmail = $_POST['wr_lid_email'];
			$wrLMSLink = $_POST['wr_lms_link'];
			$wrUserName = $_POST['wr_username'];
			$wrPassword = $_POST['wr_password'];
			$wrCourseLink = $_POST['wr_course_link'];
			$wrCourseLoc = $_POST['wr_course_loc'];
			$wrDataCourseLaunch = $_POST['wr_date_course_launch'];
			$qaType = $_POST['wr_qa_type'];
			$qaLevel = $_POST['wr_qa_level'];
			$qaDesc =  $_POST['wr_qa_desc'];
			
		
			$postQAResponse1 = $wrikeAPIPOSTCalls->postQAData($key,$clientID,$clientSecret,$task,$parentId,$parents,$titleNew,
				$wrWorkComplete, $wrCoidEmail, $wrLidEmail, $wrLMSLink, $wrUserName, $wrPassword, $wrCourseLink, $wrCourseLoc,
				$wrDataCourseLaunch, $qaType, $qaLevel,$qaDesc );
			
			
			// return link to record
			$permalink = $postQAResponse1['data'][0]['permalink'];
			
			$response = array(
				'title' => "Request Complete: QA",
				'text' => "Below are links to the new items:",
				'results' => "$permalink"
			);
				echo json_encode($response);
			break;
			
		}
		if($_POST['wr_qa_type'] == 'Back and Front') {
			$parentId = "IEAAHSNFI4AZL6YK";
			if($multiID){
			$parents = "'$parentId','$multiID'";
			}
			else{
				$parents = "'$parentId'";
			}
			$titleNew = str_replace("_QA Date Deadline: QA Request Made", "", $title);
			$titleNew  = $titleNew."_QA Front-End";
			$wrWorkComplete =  $_POST['wr_date_work_complete'];
			$wrCoidEmail = $_POST['wr_coid_email'];
			$wrLidEmail = $_POST['wr_lid_email'];
			$wrLMSLink = $_POST['wr_lms_link'];
			$wrUserName = $_POST['wr_username'];
			$wrPassword = $_POST['wr_password'];
			$wrCourseLink = $_POST['wr_course_link'];
			$wrCourseLoc = $_POST['wr_course_loc'];
			$wrDataCourseLaunch = $_POST['wr_date_course_launch'];
			$qaType = $_POST['wr_qa_type'];
			$qaLevel = $_POST['wr_qa_level'];
			$qaDesc =  $_POST['wr_qa_desc'];
			
			$postQAResponse1 = $wrikeAPIPOSTCalls->postQAData($key,$clientID,$clientSecret,$task,$parentId,$parents,$titleNew,
				$wrWorkComplete, $wrCoidEmail, $wrLidEmail, $wrLMSLink, $wrUserName, $wrPassword, $wrCourseLink, $wrCourseLoc,
				$wrDataCourseLaunch, $qaType, $qaLevel,$qaDesc );
			
			// return link to record
			$permalink1 = $postQAResponse1['data'][0]['permalink'];
			
			
			//run for backend as well
			$titleNew = str_replace("_QA Date Deadline: QA Request Made", "", $title);
			$titleNew  = $titleNew."_QA Back-End";
			$parentId2 = "IEAAHSNFI4A5SOX6";
			if($multiID){
			$parents = "'$parentId2','$multiID'";
			}
			else{
				$parents = "'$parentId2'";
			}
			$wrWorkComplete =  $_POST['wr_date_work_complete'];
			$wrCoidEmail = $_POST['wr_coid_email'];
			$wrLidEmail = $_POST['wr_lid_email'];
			$wrLMSLink = $_POST['wr_lms_link'];
			$wrUserName = $_POST['wr_username'];
			$wrPassword = $_POST['wr_password'];
			$wrCourseLink = $_POST['wr_course_link'];
			$wrCourseLoc = $_POST['wr_course_loc'];
			$wrDataCourseLaunch = $_POST['wr_date_course_launch'];
			$qaType = $_POST['wr_qa_type'];
			$qaLevel = $_POST['wr_qa_level'];
			$qaDesc =  $_POST['wr_qa_desc'];
			
			$postQAResponse2 = $wrikeAPIPOSTCalls->postQAData($key,$clientID,$clientSecret,$task,$parentId2,$parents,$titleNew,
				$wrWorkComplete, $wrCoidEmail, $wrLidEmail, $wrLMSLink, $wrUserName, $wrPassword, $wrCourseLink, $wrCourseLoc,
				$wrDataCourseLaunch, $qaType, $qaLevel,$qaDesc );
	
			
			// return link to record
			$permalink2 = $postQAResponse2['data'][0]['permalink'];
			
			$response = array(
				'title' => "Request Complete: QA",
				'text' => "Below are links to the new items:",
				'results' => "$permalink1, $permalink2"
			);
				echo json_encode($response);
			break;

		}
		if($_POST['wr_qa_type'] == 'Front Only') {
			$titleNew = str_replace("_QA Date Deadline: QA Request Made", "", $title);
			$titleNew  = $titleNew."_QA Front-End";
			$parentId = "IEAAHSNFI4AZL6YK";
			if($multiID){
			$parents = "'$parentId','$multiID'";
			}
			else{
				$parents = "'$parentId'";
			}
			$wrWorkComplete =  $_POST['wr_date_work_complete'];
			$wrCoidEmail = $_POST['wr_coid_email'];
			$wrLidEmail = $_POST['wr_lid_email'];
			$wrLMSLink = $_POST['wr_lms_link'];
			$wrUserName = $_POST['wr_username'];
			$wrPassword = $_POST['wr_password'];
			$wrCourseLink = $_POST['wr_course_link'];
			$wrCourseLoc = $_POST['wr_course_loc'];
			$wrDataCourseLaunch = $_POST['wr_date_course_launch'];
			$qaType = $_POST['wr_qa_type'];
			$qaLevel = $_POST['wr_qa_level'];
			$qaDesc =  $_POST['wr_qa_desc'];
			
			$postQAResponse = $wrikeAPIPOSTCalls->postQAData($key,$clientID,$clientSecret,$task,$parentId,$parents,$titleNew,
				$wrWorkComplete, $wrCoidEmail, $wrLidEmail, $wrLMSLink, $wrUserName, $wrPassword, $wrCourseLink, $wrCourseLoc,
				$wrDataCourseLaunch, $qaType, $qaLevel,$qaDesc );

			
			// return link to record
			$permalink = $postQAResponse['data'][0]['permalink'];
			$response = array(
				'title' => "Request Complete: QA",
				'text' => "Below are links to the new items:",
				'results' => "$permalink"
			);
			echo json_encode($response);
			break;
				
		}


}



?>



