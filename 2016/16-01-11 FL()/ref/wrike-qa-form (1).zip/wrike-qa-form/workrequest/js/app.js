var info = {
	"emailAddress": "Filtering happens against all email addresses found \"as-is\" within Wrike. \n\nFor example: searching for a complete first name of someone who's email address is <jSnow@domain.com> will return zero results.",

	"contentLocation": "Wondering where to get content for a task? The task's creator will define this process by selecting one option: \n\n1) Attached to the Wrike task, \n2) Sent upon a request email, or \n3) at a custom location or another method of retrieval. \n\nIt is the responsibility of each creator to manage file distribution, such as uploading all files into Wrike after the appropriate task has been created.",

	"qaLevel": "The level of detail a QA process entails: \n\nFull \nLinks, media, all assignment information, and full copyedit. \n\nMajor \nLinks, media, all assignment information, and copyedit on areas of heavy change. \n\nStandard \nLinks, media, assignment date check on areas of heavy change, and copyedit on areas of heavy change. \n\nBasic \nLinks and media only."
}

// New functionality needs?
//		File upload
//			Previous Allowable Types: pdf,doc,docx,xls,csv,txt,rtf,html,zip,mp3,wma,mpg,flv,avi,jpg,jpeg,png,gif


var app = new function () {
	var self = this;

	this.init = function(){
		self.toggleWorkType();
		self.radioInputBox('wr_ce_loc3');
		self.radioInputBox('wr_ts_loc3');
	}

	this.toggleWorkType = function(){
		var el = document.getElementById('wr_work_type');
		for(var i in el){
			try{
				document.getElementById(el[i].value).disabled = true;
				document.getElementById(el[i].value).style.display = 'none';
			}
			catch(e){}
		}
		try{
			document.getElementById(el.value).disabled = false;
			document.getElementById(el.value).style.display = 'block';
		}
		catch(e){}
	}

	this.radioInputBox = function(id){
		var el = document.getElementById(id);
		var radio = el.getElementsByTagName('input')[0];
		var text = el.getElementsByTagName('input')[1];

		text.addEventListener('focus', function(){
			radio.checked = true;
		});

		radio.addEventListener('change', function(){
			text.focus();
		});
	}
}