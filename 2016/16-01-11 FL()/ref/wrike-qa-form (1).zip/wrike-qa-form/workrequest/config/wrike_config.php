<?php

$wrikeConfig = array(
	"devMode" => "false",
 	"logging" => "true",
	"clientID" => "oWtYua12",
	"clientSecrete" => "b9GlCV6yZCCm8R0ZPwnVjbRubaPRyUdSi6wmW5S2R1559XdZAZ0VZ7OrurXAY9oH",
    "processNameCE"=>"Copyedit",
    "processNameTS"=>"Transcription",
    "processNameQA"=>"Quality Assurance",
    "projectTasks"=>"_QA Date Deadline: QA Request Made",
    "projectSubfolderCE"=>"Multimedia Design and Development",
    "folderCE"=>"60488361",
    "projectTaskSuffixCE"=>"_Copyedit",
    "projectTaskSuffixTS"=>"_Transcription"
   
);



?>




