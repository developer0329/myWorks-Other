<?php
require_once( dirname(__FILE__) . "/controller/logging.php" );
require_once( dirname(__FILE__) . "/config/wrike_config.php" );
require_once( dirname(__FILE__) . "/controller/wrike_api_authentication.php");
require_once( dirname(__FILE__) . "/controller/wrike_api_get_calls.php");


// declar get variables
$clientID = $wrikeConfig["clientID"];
$clientSecret = $wrikeConfig["clientSecrete"];
$code = $_GET["code"];

// delcar classes
$wrikeAPIAuth = new WrikeAPIAuth();
$wrikeAPIGetCalls = new WrikeAPIGetCalls();

// declar logger
$logger = new Logger();

// get auth get 
$key = $wrikeAPIAuth->getRefreshKey($code,$clientID,$clientSecret);

if($key=='error'){
	$url = "https://www.wrike.com/oauth2/authorize?client_id=$clientID&response_type=code" ;
	
	header("Location: https://www.wrike.com/oauth2/authorize?client_id=$clientID&response_type=code"); /* Redirect browser */
	exit();
		
}

// get list of tasks and set them as javascript data array
$tasks = $wrikeAPIGetCalls->getTasks($key,$clientID,$clientSecret);
$tasks = json_decode($tasks,true);
//print_r($tasks);

$listTasks = '';
foreach ($tasks['data'] as $task){
	if($wrikeConfig["devMode"] === "false"){
		if ( !preg_match("~\bQA Date Deadline: QA Request Made\b~",$task['title']) ){
			
			if (strpos($task['title'],'Back-End') === false) {
				if (strpos($task['title'],'Front-End') === false) {

					$title = str_replace( $wrikeConfig["projectTasks"], '', $task['title'] );
					$listTasks .= '<option value="'. $task['id'] .'">'. $title .'</option>';
				}
			}
		}
	}
	
	// if($wrikeConfig["devMode"] === "true"){
// 		
				// $title = str_replace( $wrikeConfig["projectTasks"], '', $task['title'] );
			// $listTasks .= '<option value="'. $task['id'] .'">'. $title .'</option>';
// 		
	// }
	
}


		$title = str_replace( $wrikeConfig["projectTasks"], '', $task['title'] );
		$listTasks .= '<option value="IEAAHSNFKQBZ2XWO">Test</option>';
	


// get contact emails and set them as javascript data array
$contacts = $wrikeAPIGetCalls->getContacts($key,$clientID,$clientSecret);
//echo $tasks;
$contacts = json_decode($contacts,true);

$tmp_allUsers = '[';
//print_r($contacts);
foreach ($contacts['data'] as $contact){
	//print_r($contact);
	//echo $contact['profiles'][0]['email']."\n";
	$email = $contact['profiles'][0]['email'];
	if($email != ""){
	$tmp_allUsers .= '"'. $contact['profiles'][0]['email'] .'",';
	}
}

//$logger->writeToLog("tmp_allUsers",$tmp_allUsers);

$allUsers = rtrim( $tmp_allUsers, ',' ) .']';
unset( $tmp_allUsers );


// Function for formatting custom template response results after submit
function FormatResults( $results ) {
	$return = '';
	if( gettype($results) === 'array' ) {
		$return = '<ul>';
		foreach( $results as $result ) {
			if( strpos($result,'http') == 0 ) $return .= '<li><a href="'. $result .'" target="new">'. $result .'</a></li>';
			else $return .= '<li>'. $result .'</li>';
		}
		$return .= '</ul>';
	}
	else $return = '<p>'. $results .'</p>';
	return $return;
}


$task = $wrikeAPIGetCalls->getTaskByID($key,$clientID,$clientSecret,"62118588");
		
console.log($task)
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Work Request</title>
	<link rel="stylesheet" href="js/libs/jqueryUI/jquery-ui.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="js/libs/jquery-1.10.2.js"></script>
	<script src="js/libs/jqueryUI/jquery-ui.min.js"></script>
	<script src="js/libs/jqueryUI/jquery-ui-combobox.js"></script>
	<script src="js/app.js"></script>
</head>

<script>
$(function() {
	var emails = <?php echo $allUsers?>;
	$( "#wr_coid_email" ).autocomplete({ source: emails });
	$( "#wr_lid_email" ).autocomplete({ source: emails });
	$( "#wr_date_course_launch" ).datepicker();
	$( "#wr_date_work_complete" ).datepicker();
	$( "#wr_ce_task" ).combobox();
	$( "#wr_ts_task" ).combobox();
	$( "#wr_qa_task" ).combobox();
});
$( document ).ready(function() {
	$(function () {

        $('form').on('submit', function (e) {
          e.preventDefault();
		  $('html,body').scrollTop(0);
		  $("#loading-spinner").show();
          $.ajax({
            type: 'post',
            url: 'form/submit.php',
            data: $('form').serialize(),
            success: function (data) {
              console.log(data)
				 $("#loading-spinner").hide();
              //{"title":"Request Complete: QA","text":"Below are links to the new items:","results":"https:\/\/www.wrike.com\/open.htm?id=64767587 https:\/\/www.wrike.com\/open.htm?id=64767588"}
			   var obj = $.parseJSON(data);
			   var title = obj.title;
			   var text = obj.text;
			   var results = obj.results;
			   resultsLink = '';
			   
			   if (results.indexOf(",") >= 0) {
			   		var res = results.split(",");
			   		for (i = 0; i < res.length; i++) {
					    resultsLink = resultsLink +"<p><a target='_blank' href='"+res[i]+"'>"+res[i]+"</a></p>";
					}
			    } else {
			     resultsLink = "<a target='_blank' href='"+results+"'>"+results+"</a>";
			    }
			   
			   var titleText = "<h2>"+title+"</h2>";
			   var textText = "<p>"+text+"<p>";
			   var resultsText = "<p>"+resultsLink+"<p>";
			   $("#response_title").html(titleText);
			   $("#response_text").html(textText);
			   $("#response_results").html(resultsText);
			  
            }
          });
           $(".reset").click();
		
        });
       

      });
});

 

</script>

<body onload="app.init()">
	
	<div id="work_response">
		<img id="loading-spinner" src="images/spinner_60.gif" style="display:none;margin: 10px 0px 0px 187px;" class="loading">
		<div id="response_title"></div>
		<div id="response_text"></div>
		<div id="response_results"></div>
	</div>


	<form id="work_request">
		<h2>Work Request</h2>

		<div class="wr_buttons">
			<button type="submit" class="submit">Submit</button>
			<button type="reset" class="reset">Reset</button>
		</div>

		<div class="">
			<img src="images/infoIcon.gif" class="info" title="Filter against exact email address. (click for details)" onclick="alert(info.emailAddress)">
			<label for="wr_coid_email">Co ID Email</label>
			<input type="email" id="wr_coid_email" name="wr_coid_email" maxlength="254">
		</div>

		<div class="">
			<img src="images/infoIcon.gif" class="info" title="Filters against exact email address. (click for details)"  onclick="alert(info.emailAddress)">
			<label for="wr_lid_email">Lead ID Email</label>
			<input type="email" id="wr_lid_email" name="wr_lid_email" maxlength="254">
		</div>

		<div class="required">
			<label for="wr_date_work_complete">Work Due Date</label>
			<input type="text" id="wr_date_work_complete" name="wr_date_work_complete" placeholder="mm/dd/yyyy" pattern="\d{1,2}/\d{1,2}/\d{4}" required>
		</div>

		<div class="required">
			<label for="wr_work_type">Type of Work</label>
			<select type="select" id="wr_work_type" name="wr_work_type" onchange="app.toggleWorkType()" required>
				<option value="ce" selected><?php echo $wrikeConfig["processNameCE"];?></option>
				<option value="ts" selected><?php echo $wrikeConfig["processNameTS"];?></option>
				<option value="qa" selected><?php echo $wrikeConfig["processNameQA"]; ?></option>
			</select>
		</div>

		<fieldset id="ce">
			<legend><?php echo $wrikeConfig["processNameCE"];?></legend>

			<div class="required">
				<label for="wr_ce_task">Course</label>
				<select type="text" id="wr_ce_task" name="wr_ce_task" required>
					<option/>
					<?php echo $listTasks?>
				</select>
			</div>

			<fieldset class="radio">
				<legend>
					<span>Content Location</span>
					<img src="images/infoIcon.gif" class="info" title="Where this request's content can be found. (click for details)"  onclick="alert(info.contentLocation)">
				</legend>
				<ul>
					<li>
						<input id="wr_ce_loc1" name="wr_ce_loc" type="radio" value="Attached to Wrike task">
						<label for="wr_ce_loc1">Attached to Wrike task</label>
					<li>
						<input id="wr_ce_loc2" name="wr_ce_loc" type="radio" value="Sent upon request" checked>
						<label for="wr_ce_loc2">Sent upon request</label>
					<li>
						<div id="wr_ce_loc3">
							<input type="radio" name="wr_ce_loc" value="other">
							<input type="text" name="wr_ce_loc_input" placeholder="Other">
						</div>
					</li>
				</ul>
			</fieldset>

			<div class="">
				<label for="wr_ce_desc">Length of Documents</label>
				<textarea type="textarea" id="wr_ce_desc" name="wr_ce_desc" placeholder="List all documents and the number of pages/slides in each file."></textarea>
			</div>
		</fieldset>

		<fieldset id="ts">
			<legend><?php echo $wrikeConfig["processNameTS"] ?></legend>

			<div class="required">
				<label for="wr_ts_task">Course</label>
				<select type="text" id="wr_ts_task" name="wr_ts_task" required>
					<option/>
					<?php echo $listTasks ?>
				</select>
			</div>

			<fieldset class="radio">
				<legend>
					<span>Content Location</span>
					<img src="images/infoIcon.gif" class="info" title="Where this request's content can be found. (click for details)"  onclick="alert(info.contentLocation)">
				</legend>
				<ul>
					<li>
						<input id="wr_ts_loc1" name="wr_ts_loc" type="radio" value="Attached to Wrike task">
						<label for="wr_ts_loc1">Attached to Wrike task</label>
					<li>
						<input id="wr_ts_loc2" name="wr_ts_loc" type="radio" value="Sent upon request" checked>
						<label for="wr_ts_loc2">Sent upon request</label>
					<li>
						<div id="wr_ts_loc3">
							<input type="radio" name="wr_ts_loc" value="other">
							<input type="text" name="wr_ts_loc_input" placeholder="Other">
						</div>
					</li>
				</ul>
			</fieldset>

			<fieldset class="radio">
				<legend>Are clips course specific?</legend>
				<ul>
					<li>
						<input id="wr_ts_specific1" name="wr_ts_specific" type="radio" value="yes" checked>
						<label for="wr_ts_specific1">Yes</label>
					<li>
						<input id="wr_ts_specific2" name="wr_ts_specific" type="radio" value="no">
						<label for="wr_ts_specific2">No</label>
					</li>
				</ul>
			</fieldset>

			<div class="">
				<label for="wr_ts_desc">Length of clips</label>
				<textarea type="textarea" id="wr_ts_desc" name="wr_ts_desc" placeholder="List all clips and their running lengths; when transcribing a portion of a clip, include both the beginning and ending timestamps."></textarea>
			</div>
		</fieldset>

		<fieldset id="qa">
			<legend><?php echo $wrikeConfig["processNameQA"]?></legend>

			<div class="required">
				<label for="wr_qa_task">Course</label>
				<select type="text" id="wr_qa_task" name="wr_qa_task" required>
					<option/>
					<?php echo $listTasks?>
				</select>
			</div>

			<fieldset class="radio">
				<legend>Type of QA</legend>
				<ul>
					<li>
						<input id="wr_qa_type1" name="wr_qa_type" type="radio" value="Back and Front" checked>
						<label for="wr_qa_type1">Back and Front</label>
					<li>
						<input id="wr_qa_type2" name="wr_qa_type" type="radio" value="Back Only">
						<label for="wr_qa_type2">Back Only</label>
					<li>
						<input id="wr_qa_type3" name="wr_qa_type" type="radio" value="Front Only">
						<label for="wr_qa_type3">Front Only</label>
					</li>
				</ul>
			</fieldset>

			<fieldset class="radio">
				<legend>
					<span>Level of QA</span>
					<img src="images/infoIcon.gif" class="info" title="How thorough the QA process should be. (click for details)"  onclick="alert(info.qaLevel)">
				</legend>
				<ul>
					<li>
						<input id="wr_qa_level1" name="wr_qa_level" type="radio" value="Full (links, media, all assignment information, review text for egregious errors only)">
						<label for="wr_qa_level1">Full</label>
					<li>
						<input id="wr_qa_level2" name="wr_qa_level" type="radio" value="Major (links, media, all assignment information, proofread text in areas of heavy change)">
						<label for="wr_qa_level2">Major</label>
					<li>
						<input id="wr_qa_level3" name="wr_qa_level" type="radio" value="Standard (links, media, assignment date check on areas of heavy change, proofread text in areas of heavy change)" checked>
						<label for="wr_qa_level3">Standard</label>
					<li>
						<input id="wr_qa_level4" name="wr_qa_level" type="radio" value="Basic (check of links and media only)*">
						<label for="wr_qa_level4">Basic</label>
					</li>
				</ul>
			</fieldset>

			<div class="">
				<label for="wr_qa_desc">QA Notes</label>
				<textarea type="textarea" id="wr_qa_desc" name="wr_qa_desc"></textarea>
			</div>
		</fieldset>

		<fieldset>
			<legend>Login</legend>

			<div class="">
				<label for="wr_lms_link">LMS Link</label>
				<input type="url" id="wr_lms_link" name="wr_lms_link" maxlength="2048">
			</div>

			<div class="">
				<label for="wr_username">Username</label>
				<input type="text" id="wr_username" name="wr_username" maxlength="127">
			</div>

			<div class="">
				<label for="wr_password">Password</label>
				<input type="text" id="wr_password" name="wr_password" maxlength="127">
			</div>
		</fieldset>

		<fieldset>
			<legend>Course</legend>

			<div class="">
				<label for="wr_course_link">Course/FTP Link</label>
				<input type="text" id="wr_course_link" name="wr_course_link" maxlength="2048">
			</div>

			<fieldset class="radio required">
				<legend>Course Location</legend>
				<ul>
					<li>
						<input id="wr_course_loc2" name="wr_course_loc" type="radio" value="Chicago/Toronto" required>
						<label for="wr_course_loc2">Chicago/Toronto</label>
					<li>
						<input id="wr_course_loc3" name="wr_course_loc" type="radio" value="Orlando" required>
						<label for="wr_course_loc3">Orlando</label>
					</li>
				</ul>
			</fieldset>

			<div class="required">
				<label for="wr_date_course_launch">Launch Date</label>
				<input type="text" id="wr_date_course_launch" name="wr_date_course_launch" placeholder="mm/dd/yyyy" pattern="\d{1,2}/\d{1,2}/\d{4}" required>
			</div>
		</fieldset>

		<div hidden>
			<label for="wr_file_upload"></label>
			<input type="file" id="wr_file_upload" name="wr_file_upload">
		</div>

			<input type="hidden" name="key" value="<?php echo $key?>">
		<div class="wr_buttons">
			<button type="submit" class="submit">Submit</button>
			<button type="reset">Reset</button>
		</div>
	</form>
</body>
</html>







