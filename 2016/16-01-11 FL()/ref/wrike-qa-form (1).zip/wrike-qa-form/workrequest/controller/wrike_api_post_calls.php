<?php
require_once( dirname(dirname(__FILE__) ). "/controller/logging.php" );
require_once( dirname(__FILE__) . "/wrike_api_authentication.php");
require_once( dirname(dirname(__FILE__)). "/config/wrike_config.php" );


class WrikeAPIPostCalls
{
	// method to post copywrite data	
	public static function postCEData($key,$clientID,$clientSecret,$taskCE,$parentId,$parentIds,$projectTaskCE,
			$wrWorkComplete,$wrCeDesc,$wrCELoc,$wrCELocInput,$wrCoidEmail,$wrLMSLink,$wrUserName,$wrPassword,$wrCourseLink,
			$wrCourseLoc,$wrDataCourseLaunch,$titleNew,$wrLidEmail)
	{
		//delcar logger
		$logger = new Logger();
		
		// get access key
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);
		
		// set up and POST data
		$url = "https://www.wrike.com/api/v3/folders/$parentId/tasks";		
		$today = new DateTime();
		$dueDate = DateTime::createFromFormat('n/j/Y', $wrWorkComplete);
		$daysDiff = $today->diff( $dueDate, true );
		$daysAllowed = 7;
		$arr = array();
		$titleNew;
		$discription =  "Summary: ". $wrCeDesc
			."<br>File Location: ". ($wrCELoc === 'other' ? $wrCELocInput : $wrCELoc)
			."<br>"
			."<br>Co ID Email: ". $wrCoidEmail
			."<br>Lead ID Email: ". $wrLidEmail
			."<br>"
			."<br>LMS Login Link: ". $wrLMSLink
			."<br>Username: ". $wrUserName
			."<br>Password: ". $wrPassword
			."<br>"
			."<br>Course/FTP Link: ". $wrCourseLink
			."<br>Course Location: ". $wrCourseLoc
			."<br>Course Launch: ". $wrDataCourseLaunch;
		$startDate = $today->format("Y-m-d"); // format ex. "2013-01-01T09:00:00"
		$dueDate= $dueDate->format("Y-m-d"); // format ex. "2013-01-01T09:00:00"
		$importance = ((int)$daysDiff->format('%a') <= (int)$daysAllowed) ? "Normal" : "High";
		
		// logging
		$logger->writeToLog("$startDate",$startDate);
		$logger->writeToLog("$dueDate",$dueDate);

		$parents = $parentIds;
		$logger->writeToLog("$parents",$parents);
		
		$fields = array(
			'title' => $titleNew,
			'description' => $discription,
			'dates' => "{'start':'$startDate','due':'$dueDate'}",
			'importance' => $importance,
			'parents' => "[$parents]",
		);
		
		$fields_string = '';
		
		foreach($fields as $key2=>$value2) { $fields_string .= $key2.'='.$value2.'&'; }
		rtrim($fields_string, '&');
	
		$ch = curl_init();
		
		//set the url, number of POST vars, POST data
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_POST, count($fields));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));     
		//execute post
		$result = curl_exec($ch);
		
		//close connection
		curl_close($ch);
		
		//logging
		$logger->writeToLog("Logging Post CE Results",$result);
		
		// get and return results
		$postCEResults = json_decode($result,true);
		
		return $postCEResults;

	}

	//POST method for transcription request
	public static function postTSData($key,$clientID,$clientSecret,$taskCE,$parentId,$parentIds,$projectTaskTS,
		$wrWorkComplete,$wrTSDesc,$wrTSLoc,$wrTSSpecific,$wrTSLocInput,$wrCoidEmail,$wrLMSLink,$wrUserName,$wrPassword,$wrCourseLink,
		$wrCourseLoc,$wrDataCourseLaunch,$titleNew,$wrLidEmail)
	{
		
		//delcar logger
		$logger = new Logger();
		
		// get access key
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);
		
		// set and post data
		$url = "https://www.wrike.com/api/v3/folders/$parentId/tasks";	
		$today = new DateTime();
		$dueDate = DateTime::createFromFormat('n/j/Y', $wrWorkComplete);
		$daysDiff = $today->diff( $dueDate, true );
		$daysAllowed = 7;
		$titleNew;
		$discription = "Summary: ". $wrTSDesc
		."<br>File Location: ". ($wrTSLoc === 'other' ? $wrTSLocInput : $wrTSLoc)
		."<br>Course specific clips: ". $wrTSSpecific
		."<br>"
		."<br>Co ID Email: ". $wrCoidEmail
		."<br>Lead ID Email: ". $wrLidEmail
		."<br>"
		."<br>LMS Login Link: ". $wrLMSLink
		."<br>Username: ". $wrUserName
		."<br>Password: ". $wrPassword
		."<br>"
		."<br>Course/FTP Link: ". $wrCourseLink
		."<br>Course Location: ". $wrCourseLoc
		."<br>Course Launch: ". $wrDataCourseLaunch;
		$startDate = $today->format("Y-m-d"); // format ex. "2013-01-01T09:00:00"
		$dueDate= $dueDate->format("Y-m-d"); // format ex. "2013-01-01T09:00:00"
		$importance = ((int)$daysDiff->format('%a') <= (int)$daysAllowed) ? "Normal" : "High";
		$logger->writeToLog("$startDate",$startDate);
		$logger->writeToLog("$dueDate",$dueDate);

		$parents = $parentIds;
		
		$fields = array(
			'title' => $titleNew,
			'description' => $discription,
			'dates' => "{'start':'$startDate','due':'$dueDate'}",
			'importance' => $importance,
			'parents' => "[$parents]",
		);
		
		$fields_string = '';

		foreach($fields as $key2=>$value2) { $fields_string .= $key2.'='.$value2.'&'; }
		rtrim($fields_string, '&');
	
		$ch = curl_init();
		
		//set the url, number of POST vars, POST data
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_POST, count($fields));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));     
		//execute post
		$result = curl_exec($ch);
		
		//close connection
		curl_close($ch);

		// logging
		$logger->writeToLog("Logging Post TS Results",$result);
		
		// get results and return them
		$postTSResults = json_decode($result,true);
		
		return $postTSResults;

	}

	// POST method for QA requets
	public static function postQAData($key,$clientID,$clientSecret,$task,$parentId,$parentIds,$titleNew,
			$wrWorkComplete, $wrCoidEmail, $wrLidEmail, $wrLMSLink, $wrUserName, $wrPassword, $wrCourseLink, $wrCourseLoc,
			$wrDataCourseLaunch, $qaType, $qaLevel,$qaDesc)
	{
		// declare logger 
		$logger = new Logger();
		
		$logger->writeToLog("QA parentId",$parentId);
	
		// get access token
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);
		$url = "https://www.wrike.com/api/v3/folders/$parentId/tasks";	

		// set and POST data
		$today = new DateTime();
		$dueDate = DateTime::createFromFormat('n/j/Y', $wrWorkComplete);
		$daysDiff = $today->diff( $dueDate, true );
		$daysAllowed = 7;
		$titleNew;
		$discription = "QA Type: ". $qaType
			."<br>Level of QA: ". $qaLevel
			."<br>Summary: ". $qaDesc
			."<br>"
			."<br>Co ID Email: ". $wrCoidEmail
			."<br>Lead ID Email: ". $wrLidEmail
			."<br>"
			."<br>LMS Login Link: ". $wrLMSLink
			."<br>Username: ". $wrUserName
			."<br>Password: ". $wrPassword
			."<br>"
			."<br>Course/FTP Link: ". $wrCourseLink
			."<br>Course Location: ". $wrCourseLoc
			."<br>Course Launch: ". $wrDataCourseLaunch;
		$startDate = $today->format("Y-m-d"); // format ex. "2013-01-01T09:00:00"
		$dueDate= $dueDate->format("Y-m-d"); // format ex. "2013-01-01T09:00:00"
		$importance = ((int)$daysDiff->format('%a') <= (int)$daysAllowed) ? "Normal" : "High";
		$logger->writeToLog("$startDate",$startDate);
		$logger->writeToLog("$dueDate",$dueDate);
		
		$parents = $parentIds;
				
		$fields = array(
			'title' => $titleNew,
			'description' => $discription,
			'dates' => "{'start':'$startDate','due':'$dueDate'}",
			'importance' => $importance,
			'parents' => "[$parents]",
		);
		
		$fields_string = '';
		foreach($fields as $key2=>$value2) { $fields_string .= $key2.'='.$value2.'&'; }
		rtrim($fields_string, '&');
	
		$ch = curl_init();
		
		//set the url, number of POST vars, POST data
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_POST, count($fields));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));     
		//execute post
		$result = curl_exec($ch);
		
		//close connection
		curl_close($ch);
		
		//logging
		$logger->writeToLog("Logging Post QA Results",$result);
		
		// get results and return them
		$postTSResults = json_decode($result,true);
		
		return $postTSResults;

	}
	
}




?>



