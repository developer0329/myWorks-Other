<?php

// declar includes
require_once( dirname(dirname(__FILE__) ) . "/controller/logging.php" );


class WrikeAPIAuth
{

	// method to get auth key
    public static function getRefreshKey($code,$clientID,$clientSecret) {
 		//delcar vars	
 		$fields_string = "";
		
		// declar logger
		$logger = new Logger();
		
		//loggins
	   	$logger->writeToLog("Client ID ",$clientID);
		$logger->writeToLog("clientSecret ",$clientSecret);
			
		//set POST variables
		$url = 'https://www.wrike.com/oauth2/token';
	
		$fields = array(
			'client_id' => urlencode($clientID),
			'client_secret' => urlencode($clientSecret),
			'grant_type' => urlencode("authorization_code"),
			'code' => urlencode($code),
		);

		//url-ify the data for the POST
		foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
		rtrim($fields_string, '&');
		 
		 // logging
		 $logger->writeToLog("url ",$url);
		 $logger->writeToLog("fields_string ",$fields_string);
		 $logger->writeToLog("count fields ",count($fields));
		
		//open connection
		$ch = curl_init();
		
		//set the url, number of POST vars, POST data
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_POST, count($fields));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		//execute post
		$result = curl_exec($ch);
		
		//close connection
		curl_close($ch);

		// logging
		$logger->writeToLog("Logging API Key Command ",$result);
		
		// get response and return it 
		$refreshTokenResult = json_decode($result,true);

		if($refreshTokenResult['error']){
			
         return "error"; 
		}
		else{
			$refreshToken = $refreshTokenResult['refresh_token'];
			//$logger->writeToLog("refreshToken ",$refreshToken);
			return $refreshToken; 
		}

    }

	// method to get refresh access token
	public static function getRefreshAccessToken ($clientID,$clientSecret,$key){
		// declar  looggins	
		$logger = new Logger();
		
		// set url and GET fields
		$url = 'https://www.wrike.com/oauth2/token';
				
		$fields2 = array(
				'client_id' => urlencode($clientID),
				'client_secret' => urlencode($clientSecret),
				'grant_type' => urlencode("refresh_token"),
				'refresh_token' => urlencode($key),
		);
				
		$fields_string2 = '';

		foreach($fields2 as $key2=>$value2) { $fields_string2 .= $key2.'='.$value2.'&'; }
		rtrim($fields_string2, '&');
		 
		// logging
		$logger->writeToLog("url ",$url);
		$logger->writeToLog("fields_string ",$fields_string2);
		$logger->writeToLog("count fields ",count($fields2));
		
		//open connection
		$ch = curl_init();
		
		//set the url, number of POST vars, POST data
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_POST, count($fields2));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		//execute post
		$result2 = curl_exec($ch);
		
		//close connection
		curl_close($ch);
		
		$logger->writeToLog("result2 ", $result2);
		
		// get results and return them
		$refreshTokenResult = json_decode($result2,true);
		
		$accessToken = $refreshTokenResult['access_token'];
		
		return $accessToken;
		
	}
}




?>
