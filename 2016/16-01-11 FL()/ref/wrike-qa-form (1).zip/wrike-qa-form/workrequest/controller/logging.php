<?php

// declar includes
require_once( dirname(dirname(__FILE__) ). "/config/wrike_config.php" );


class Logger
{
	//logging class
    public static function writeToLog($event,$data) {
    	// log info if logging is set to true	
//    $logging = $wrikeConfig["logging"];
	

			// Open the file to get existing content
//			$current = file_get_contents(dirname(__FILE__)."/../logs/logs.txt");
			
			//set contents
			$dateTime = date("F j, Y, g:i a");   ;
//		$current .= "Loged Event: $event, Date: $dateTime, Data: $data\n";
			
			//put contents
//		file_put_contents(dirname( dirname(__FILE__) )."/logs/logs.txt", $current);
		}
    
}


?>


