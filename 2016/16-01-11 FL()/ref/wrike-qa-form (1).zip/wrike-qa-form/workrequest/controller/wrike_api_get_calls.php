<?php

// declar includes
require_once( dirname(dirname(__FILE__) ) . "/controller/logging.php" );
require_once( dirname(__FILE__) . "/wrike_api_authentication.php");


class WrikeAPIGetCalls
{

	// method to get wrike contact data
	public static function getContacts($key,$clientID,$clientSecret){
		// declar logging method	
		$logger = new Logger();
		
		// get access key
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);
		
		//logging
		$logger->writeToLog("accessToken for get contacts",$accessToken);
		
		//get contacts
		$url2 = "https://www.wrike.com/api/v3/contacts";	
		
		// set up the curl resource
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));       
		
		// execute the request
		$contacts = curl_exec($ch);

		//close connection
		curl_close($ch);
		
		//get contacts and return them
		$contactsSplit = explode("includeSubDomains",$contacts);
	
		$logger->writeToLog("contacts: ",$contactsSplit[1]);
		
		return $contactsSplit[1]; 

		
	}

	// metod to get tasks
	public static function getTasks($key,$clientID,$clientSecret){
		// declar logger	
		$logger = new Logger();
		
		// get access key
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);

		//logging sa
		$logger->writeToLog("accessToken for get tasks ",$accessToken);
		
		// get tasks
		$url2 = "https://www.wrike.com/api/v3/tasks?status=Active&title=_QA Date Deadline: QA Request Made&sortField=title";	
		
		$url2 = str_replace(" ","%20",$url2);
		// set up the curl resource
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));       
		
		 $info = curl_getinfo($ch);
	
		// execute the request
		$tasks = curl_exec($ch);
		
		//close connection
		curl_close($ch);
		
		$logger->writeToLog("info: ",print_r($info, true));
		
		$logger->writeToLog("RAW tasks: ",print_r($tasks, true));
		
		// get results and return them
		$tasksSplit = explode("includeSubDomains",$tasks);

		$logger->writeToLog("tasks: ",$tasksSplit[1]);
		
		$finalTasks = $tasksSplit[1];
		
		return $finalTasks; 

		
	}

	public static function getTaskByID($key,$clientID,$clientSecret,$taskID){
		$logger = new Logger();
		
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);

		$ch = curl_init();
	
		//$logger->writeToLog("accessToken for get tasks ",$accessToken);
		
	//	curl -g -X GET -H 'Authorization: bearer <access_token>' 'https://www.wrike.com/api/v3/tasks/IEAAALNZKQADAPGG,IEAAALNZKQADAPGI'
		
		
		$url2 = "https://www.wrike.com/api/v3/tasks/".$taskID;	
		// set up the curl resource
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));       
	
		// execute the request
		
		$task = curl_exec($ch);
		
		//close connection
		curl_close($ch);
		// get results and return them
		$tasksSplit = explode("includeSubDomains",$task);

		$logger->writeToLog("tasks: ",$tasksSplit[1]);
		
		$finalTasks = $tasksSplit[1];
		
		return $finalTasks; 
	}

	public static function getFolderInfo($key,$clientID,$clientSecret,$parentIdFromData){
		$logger = new Logger();
		
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);

		$ch = curl_init();
	

		$url2 = "https://www.wrike.com/api/v3/folders/$parentIdFromData";	
		// set up the curl resource
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));       
	
		// execute the request
		
		$folder = curl_exec($ch);
		
		//close connection
		curl_close($ch);
		// get results and return them
		$tasksSplit = explode("includeSubDomains",$folder);

		$logger->writeToLog("getFolderInfo: ",$tasksSplit[1]);
		
		$finalTasks = $tasksSplit[1];
		
		return $finalTasks; 

		
	}

	public static function getParentIdFolderTree($key,$clientID,$clientSecret,$parentIdFromData){
		$logger = new Logger();
		
		$wrikeAPIAuth = new WrikeAPIAuth();
		$accessToken =  $wrikeAPIAuth->getRefreshAccessToken($clientID,$clientSecret,$key);

		$ch = curl_init();
	

		$url2 = "https://www.wrike.com/api/v3/folders/$parentIdFromData/folders";	
		// set up the curl resource
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url2);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		   "Authorization: bearer $accessToken",                                                                                                                                                       
		));       
	
		// execute the request
		
		$folderTree = curl_exec($ch);
		
		//close connection
		curl_close($ch);
			// get results and return them
		$tasksSplit = explode("includeSubDomains",$folderTree);

		$logger->writeToLog("getParentIdFolderTree: ",$tasksSplit[1]);
		
		$finalTasks = $tasksSplit[1];
		
		return $finalTasks; 

		
	}
}





?>


