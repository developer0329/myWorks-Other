Simpalm team- Please ignore the "Report Builder" folder. I am relatively sure it does not contain any dependencies for the QA Work Request code. 
If, after exploring the QA code, you can confirm no dependencies in the Report Builder folder, feel free to remove it from the repo.

# Wrike Tools


The project was originally meant to contain 2 tools:

- QA Work Request
- Report Builder (Incomplete)

However, the Report Builder is incomplete and has spun off into a separate project due to the Wrike API being updated to Restful services.


****

A single DNS entry points to an Amazon ELB, which is configured with 2 proxies and each proxy has 1 internal facing server.

## Configuration
* DOMAIN:: prv-openclass.com

* DNS:: cname== wriketools

* ELB:: prd-pu-46-wriketools-0004

**Old - but still active using m1 and t1 instances**

* HAPROXY:: prd-use1b-pu-46-wriketoolspr-hapy-0003 (10.198.9.219)
* SERVER:: prd-use1b-pr-46-wriketools-prod-0001 (10.198.10.75)

**New - uses t2 instances**

* HAPROXY:: prd-use1b-pu-46-wriketoolsqa-hapy-0002 (10.198.9.107)
* SERVER:: prd-use1b-pr-46-wriketoolsqa-prod-0001 (10.198.14.146)

You can always get the HAProxy's status by going to port 10000 on prv-openclass.com, for example: http://prd-use1b-pu-46-wriketoolsqa-hapy-0002.prv-openclass.com:10000/overview.

## Documentation:
* Nibiru APIs - https://nibiru-prod.prsn.us/api/doc/
  * loadbalancers - https://nibiru-prod.prsn.us/api/doc/loadbalancers/
  * haproxy - https://nibiru-prod.prsn.us/api/doc/applications/haproxy/
* Thalassa-Aqueduct (HAProxy front/backends) - https://github.com/PearsonEducation/thalassa-aqueduct
* Comprehensive Guide to Nibiru v2 - https://confluence.pearson.com/confluence/pages/viewpage.action?title=Comprehensive+Guide+to+Nibiru+v2&spaceKey=eSAT
* Nibiru Documentation Catalog - https://neo.pearson.com/groups/nibiru/projects/nibiru-documentation
