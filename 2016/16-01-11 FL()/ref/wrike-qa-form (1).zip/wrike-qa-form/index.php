<?php
require_once( dirname(__FILE__) . "/workrequest/config/wrike_config.php" );
require_once( dirname(__FILE__) . "/workrequest/controller/logging.php" );

$clientID = $wrikeConfig["clientID"];


$logger = new Logger();
//$logger->writeToLog("Logging Client ID",$clientID);

$url = "https://www.wrike.com/oauth2/authorize?client_id=$clientID&response_type=code" ;
//echo $url;

header("Location: https://www.wrike.com/oauth2/authorize?client_id=$clientID&response_type=code"); /* Redirect browser */
exit();

?>


